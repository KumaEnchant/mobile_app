import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import '../api/api_service.dart'; // Pastikan import ApiService benar
import 'absen_submit_screen.dart';

class KehadiranScreen extends StatefulWidget {
  const KehadiranScreen({super.key});

  @override
  State<KehadiranScreen> createState() => _KehadiranScreenState();
}

class _KehadiranScreenState extends State<KehadiranScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool isLoading = true;

  List<Map<String, dynamic>> attendanceData = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _fetchKehadiranData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // ✅ UPDATE FUNGSI INI DI Kehadiran_screen.dart
  Future<void> _fetchKehadiranData() async {
    setState(() => isLoading = true);
    
    try {
      debugPrint("🔄 Fetching kehadiran data from server...");
      
      // KITA PANGGIL DARI API SERVICE (Bukan manual dio.get lagi)
      // Pastikan api_service.dart sudah diupdate sesuai instruksi sebelumnya
      final List<Map<String, dynamic>> data = await ApiService.getKehadiranMahasiswa();

      debugPrint("📥 Received ${data.length} items from API");

      if (data.isNotEmpty) {
        setState(() {
          attendanceData = data.map((item) {
            // Safety check untuk meetings agar tidak error
            List<Map<String, dynamic>> meetings = [];
            if (item['meetings'] != null && item['meetings'] is List) {
              meetings = (item['meetings'] as List)
                  .map((m) => m is Map ? Map<String, dynamic>.from(m) : <String, dynamic>{})
                  .toList();
            }
            
            return {
              'name': item['nama_matkul']?.toString() ?? 'Unknown',
              'code': item['kode_matkul']?.toString() ?? '',
              'lecturer': item['dosen']?.toString() ?? '',
              'idKrsDetail': int.tryParse(item['id_krs_detail'].toString()) ?? 0,
              'totalMeetings': int.tryParse(item['total_pertemuan'].toString()) ?? 14,
              'attended': int.tryParse(item['hadir'].toString()) ?? 0,
              'absent': int.tryParse(item['alpha'].toString()) ?? 0,
              'permit': int.tryParse(item['izin'].toString()) ?? 0,
              'sick': int.tryParse(item['sakit'].toString()) ?? 0,
              'percentage': _parseDouble(item['persentase']),
              'color': _getColorForIndex(data.indexOf(item)),
              'meetings': meetings,
            };
          }).toList();
          
          isLoading = false;
        });
      } else {
        // Jika data kosong, matikan loading tanpa load dummy
        debugPrint("⚠️ Data API kosong.");
        setState(() => isLoading = false);
      }
    } catch (e) {
      debugPrint("❌ Error fetch: $e");
      // Hanya load dummy jika benar-benar error koneksi/crash
      _loadDummyData();
    }
  }

  // ✅ DUMMY DATA
  void _loadDummyData() {
    setState(() {
      attendanceData = [
        {
          'name': 'Kewarganegaraan',
          'code': '1',
          'lecturer': 'Lutvi Riyandari,S.Pd,M.Si',
          'idKrsDetail': 101,
          'totalMeetings': 14,
          'attended': 0,
          'absent': 0,
          'permit': 0,
          'sick': 0,
          'percentage': 0.0,
          'color': const Color(0xFF2196F3),
          'meetings': <Map<String, dynamic>>[],
        },
         // ... tambahkan dummy lain jika perlu
      ];
      isLoading = false;
    });
  }

  double _parseDouble(dynamic value) {
    if (value == null) return 0.0;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value) ?? 0.0;
    return 0.0;
  }

  Color _getColorForIndex(int index) {
    final colors = [
      const Color(0xFF2196F3), const Color(0xFF4CAF50), const Color(0xFF9C27B0),
      const Color(0xFFFF9800), const Color(0xFFF44336), const Color(0xFF009688),
      const Color(0xFF00BCD4), const Color(0xFF673AB7), const Color(0xFFE91E63),
      const Color(0xFF607D8B),
    ];
    return colors[index % colors.length];
  }

  double get overallAttendancePercentage {
    int totalMeetingsSoFar = 0;
    int totalCountedAsPresent = 0;

    for (var course in attendanceData) {
      final meetings = course['meetings'] as List<Map<String, dynamic>>;
      totalMeetingsSoFar += meetings.length;
      totalCountedAsPresent += (course['attended'] as int) +
          (course['permit'] as int) +
          (course['sick'] as int);
    }
    return totalMeetingsSoFar > 0
        ? (totalCountedAsPresent / totalMeetingsSoFar) * 100
        : 0;
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.topRight,
              colors: [Color(0xFF2196F3), Color(0xFF1976D2)],
            ),
          ),
          child: const Center(child: CircularProgressIndicator(color: Colors.white)),
        ),
      );
    }

    final totalCourses = attendanceData.length;
    final coursesAbove75 = attendanceData.where((c) => (c['percentage'] as double) >= 75).length;
    final coursesBelow75 = totalCourses - coursesAbove75;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.topRight,
            colors: [Color(0xFF2196F3), Color(0xFF1976D2)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header & Card Statistik
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back, color: Colors.white),
                          onPressed: () => Navigator.pop(context),
                        ),
                        const Expanded(
                          child: Text(
                            'Kehadiran',
                            style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                          child: IconButton(
                            icon: const Icon(Icons.refresh, color: Color(0xFF1976D2)),
                            onPressed: _fetchKehadiranData,
                            tooltip: "Refresh data",
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 20, offset: const Offset(0, 10)),
                        ],
                      ),
                      child: Column(
                        children: [
                          Text('Persentase Kehadiran', style: TextStyle(fontSize: 14, color: Colors.grey[600])),
                          const SizedBox(height: 12),
                          Stack(
                            alignment: Alignment.center,
                            children: [
                              SizedBox(
                                width: 120, height: 120,
                                child: CircularProgressIndicator(
                                  value: overallAttendancePercentage / 100,
                                  strokeWidth: 12,
                                  backgroundColor: Colors.grey[200],
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    overallAttendancePercentage >= 75 ? const Color(0xFF4CAF50) :
                                    overallAttendancePercentage >= 50 ? const Color(0xFFFF9800) : const Color(0xFFF44336),
                                  ),
                                ),
                              ),
                              Column(
                                children: [
                                  Text(
                                    '${overallAttendancePercentage.toStringAsFixed(1)}%',
                                    style: TextStyle(
                                      fontSize: 28, fontWeight: FontWeight.bold,
                                      color: overallAttendancePercentage >= 75 ? const Color(0xFF4CAF50) :
                                      overallAttendancePercentage >= 50 ? const Color(0xFFFF9800) : const Color(0xFFF44336),
                                    ),
                                  ),
                                  Text('Keseluruhan', style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              _buildStatColumn('≥75%', '$coursesAbove75', const Color(0xFF4CAF50), 'Mata Kuliah'),
                              Container(height: 40, width: 1, color: Colors.grey[300]),
                              _buildStatColumn('<75%', '$coursesBelow75', const Color(0xFFF44336), 'Mata Kuliah'),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Tabs
              Container(
                color: Colors.transparent,
                child: TabBar(
                  controller: _tabController,
                  indicatorColor: Colors.white,
                  indicatorWeight: 3,
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.white.withOpacity(0.6),
                  tabs: const [Tab(text: 'Per Mata Kuliah'), Tab(text: 'Statistik')],
                ),
              ),

              // Content
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.grey[50],
                    borderRadius: const BorderRadius.only(topLeft: Radius.circular(30), topRight: Radius.circular(30)),
                  ),
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildCourseListTab(),
                      _buildStatisticsTab(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatColumn(String label, String value, Color color, String subtitle) {
    return Column(
      children: [
        Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: color)),
        Text(subtitle, style: TextStyle(fontSize: 11, color: Colors.grey[600])),
      ],
    );
  }

  Widget _buildCourseListTab() {
    return ListView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: attendanceData.length,
      itemBuilder: (context, index) => _buildCourseAttendanceCard(attendanceData[index]),
    );
  }

  Widget _buildCourseAttendanceCard(Map<String, dynamic> course) {
    final percentage = course['percentage'] as double;
    final color = course['color'] as Color;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 15, offset: const Offset(0, 5))],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _showCourseDetail(course),
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 5, height: 60,
                      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(10)),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
                            child: Text(
                              course['code'].toString(),
                              style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: color),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            course['name'].toString(),
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                            maxLines: 2, overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Text(course['lecturer'].toString(), style: TextStyle(fontSize: 13, color: Colors.grey[600])),
                        ],
                      ),
                    ),
                    Column(
                      children: [
                        Text(
                          '${percentage.toStringAsFixed(1)}%',
                          style: TextStyle(
                            fontSize: 24, fontWeight: FontWeight.bold,
                            color: percentage >= 75 ? const Color(0xFF4CAF50) : const Color(0xFFF44336),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey[400]),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: color.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.touch_app, size: 18, color: color),
                      const SizedBox(width: 8),
                      Text('Klik untuk lihat daftar pertemuan', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: color)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatisticsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 5))],
            ),
            child: Column(
              children: [
                Icon(Icons.calendar_month, size: 64, color: Colors.grey[400]),
                const SizedBox(height: 16),
                const Text('Statistik Kehadiran', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Data kehadiran Anda dari semua mata kuliah', textAlign: TextAlign.center, style: TextStyle(fontSize: 14, color: Colors.grey[600])),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showCourseDetail(Map<String, dynamic> course) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.8,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(topLeft: Radius.circular(30), topRight: Radius.circular(30)),
        ),
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 12),
              width: 40, height: 4,
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: (course['color'] as Color).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(Icons.book, color: course['color'] as Color, size: 28),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(course['code'].toString(), style: TextStyle(fontSize: 14, color: Colors.grey[600])),
                            Text(course['name'].toString(), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                            Text(course['lecturer'].toString(), style: TextStyle(fontSize: 13, color: Colors.grey[600])),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Text('Daftar Pertemuan (14 pertemuan)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                itemCount: 14,
                itemBuilder: (context, index) {
                  final pertemuan = index + 1;
                  final meetings = course['meetings'] as List<Map<String, dynamic>>;
                  
                  // ✅ PERBAIKAN UTAMA: Menggunakan toString() untuk perbandingan aman
                  // Mengatasi masalah ID pertemuan string ("1") vs int (1)
                  final meeting = meetings.firstWhere(
                    (m) => m['pertemuan'].toString() == pertemuan.toString(),
                    orElse: () => {},
                  );
                  
                  // Ambil status, default 'Belum absen' jika data kosong
                  final status = meeting.isNotEmpty && meeting['status'] != null 
                      ? meeting['status'] 
                      : 'Belum absen';

                  return _buildPertemuanCard(course, pertemuan, status);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPertemuanCard(Map<String, dynamic> course, int pertemuan, String status) {
    final color = course['color'] as Color;
    final isAbsent = status != 'Belum absen';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[300]!),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: isAbsent ? null : () async {
            // 1. Tutup Modal Bottom Sheet
            Navigator.pop(context);

            // 2. Buka Halaman Submit & TUNGGU hasilnya
            final result = await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AbsenSubmitScreen(
                  // ✅ PERBAIKAN: Safety parse int untuk ID KRS
                  idKrsDetail: int.parse(course['idKrsDetail'].toString()),
                  pertemuan: pertemuan,
                  namaMatkul: course['name'].toString(),
                  topic: 'Pertemuan $pertemuan',
                ),
              ),
            );

            // 3. ✅ Refresh data HANYA jika absen berhasil (result == true)
            if (result == true && mounted) {
              debugPrint("✅ Absen berhasil, merefresh data...");
              await _fetchKehadiranData();
              
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("✅ Data kehadiran diperbarui!"),
                    backgroundColor: Colors.green,
                    duration: Duration(seconds: 2),
                  ),
                );
              }
            }
          },
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 50, height: 50,
                  decoration: BoxDecoration(color: color.withOpacity(0.1), shape: BoxShape.circle),
                  child: Center(
                    child: Text('$pertemuan', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Pertemuan $pertemuan', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text(status, style: TextStyle(fontSize: 13, color: isAbsent ? Colors.green : Colors.grey[600])),
                    ],
                  ),
                ),
                if (!isAbsent)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(20)),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.camera_alt, size: 16, color: Colors.white),
                        SizedBox(width: 6),
                        Text('Absen', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white)),
                      ],
                    ),
                  )
                else
                  const Icon(Icons.check_circle, color: Colors.green, size: 32),
              ],
            ),
          ),
        ),
      ),
    );
  }
}