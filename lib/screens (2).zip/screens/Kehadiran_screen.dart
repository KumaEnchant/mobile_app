import 'package:flutter/material.dart';

class KehadiranScreen extends StatefulWidget {
  const KehadiranScreen({super.key});

  @override
  State<KehadiranScreen> createState() => _KehadiranScreenState();
}

class _KehadiranScreenState extends State<KehadiranScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // --- DATA KEHADIRAN TELAH DISESUAIKAN ---
  final List<Map<String, dynamic>> attendanceData = [
    {
      'name': 'Kewarganegaraan',
      'code': '1',
      'lecturer': 'Lutvi Riyandari,S.Pd,M.Si',
      'totalMeetings': 14, // Total rencana pertemuan satu semester
      'attended': 7, // Hanya jumlah 'Hadir'
      'absent': 0,
      'permit': 0,
      'sick': 0,
      'percentage': 100.0, // (Hadir + Izin + Sakit) / Pertemuan yg sudah berlangsung
      'color': Color(0xFF2196F3),
      'meetings': [ // 7 pertemuan yang sudah berlangsung
        {'date': '1 Sep 2025', 'status': 'Hadir', 'time': '08:32', 'topic': 'Hak dan Kewajiban Warga Negara'},
        {'date': '8 Sep 2025', 'status': 'Hadir', 'time': '08:30', 'topic': 'Identitas Nasional'},
        {'date': '15 Sep 2025', 'status': 'Hadir', 'time': '08:35', 'topic': 'Konstitusi dan UUD NRI 1945'},
        {'date': '22 Sep 2025', 'status': 'Hadir', 'time': '08:29', 'topic': 'Demokrasi Indonesia'},
        {'date': '29 Sep 2025', 'status': 'Hadir', 'time': '08:31', 'topic': 'Negara dan Warga Negara'},
        {'date': '6 Okt 2025', 'status': 'Hadir', 'time': '08:33', 'topic': 'Otonomi Daerah'},
        {'date': '13 Okt 2025', 'status': 'Hadir', 'time': '08:30', 'topic': 'Wawasan Nusantara'},
      ],
    },
    {
      'name': 'Pancasila',
      'code': '6',
      'lecturer': 'Syah Firdaus Palumpun,M.Si',
      'totalMeetings': 14,
      'attended': 6,
      'absent': 0,
      'permit': 1,
      'sick': 0,
      'percentage': 100.0,
      'color': Color(0xFF4CAF50),
      'meetings': [
        {'date': '1 Sep 2025', 'status': 'Hadir', 'time': '09:05', 'topic': 'Pengantar Pendidikan Pancasila'},
        {'date': '8 Sep 2025', 'status': 'Hadir', 'time': '09:02', 'topic': 'Sejarah Perumusan Pancasila'},
        {'date': '15 Sep 2025', 'status': 'Hadir', 'time': '09:08', 'topic': 'Pancasila sebagai Sistem Filsafat'},
        {'date': '22 Sep 2025', 'status': 'Izin', 'time': '-', 'topic': 'Pancasila sebagai Ideologi'},
        {'date': '29 Sep 2025', 'status': 'Hadir', 'time': '09:04', 'topic': 'Pancasila sebagai Sistem Etika'},
        {'date': '6 Okt 2025', 'status': 'Hadir', 'time': '09:01', 'topic': 'Pancasila dalam Konteks Sejarah'},
        {'date': '13 Okt 2025', 'status': 'Hadir', 'time': '09:06', 'topic': 'Dinamika dan Tantangan Pancasila'},
      ],
    },
    {
      'name': 'Manajemen Bisnis',
      'code': '7',
      'lecturer': 'Novita Setianti,S.E,M.Ak,Ak.CA',
      'totalMeetings': 14,
      'attended': 7,
      'absent': 0,
      'permit': 0,
      'sick': 0,
      'percentage': 100.0,
      'color': Color(0xFF9C27B0),
      'meetings': [
        {'date': '1 Sep 2025', 'status': 'Hadir', 'time': '10:33', 'topic': 'Pengantar Manajemen'},
        {'date': '8 Sep 2025', 'status': 'Hadir', 'time': '10:35', 'topic': 'Fungsi Perencanaan'},
        {'date': '15 Sep 2025', 'status': 'Hadir', 'time': '10:30', 'topic': 'Fungsi Pengorganisasian'},
        {'date': '22 Sep 2025', 'status': 'Hadir', 'time': '10:38', 'topic': 'Fungsi Pengarahan'},
        {'date': '29 Sep 2025', 'status': 'Hadir', 'time': '10:32', 'topic': 'Fungsi Pengendalian'},
        {'date': '6 Okt 2025', 'status': 'Hadir', 'time': '10:36', 'topic': 'Manajemen Pemasaran'},
        {'date': '13 Okt 2025', 'status': 'Hadir', 'time': '10:31', 'topic': 'Manajemen Keuangan'},
      ],
    },
    {
      'name': 'Agama',
      'code': '107',
      'lecturer': 'Ramelan,S.Pd,M.Pd',
      'totalMeetings': 14,
      'attended': 7,
      'absent': 0,
      'permit': 0,
      'sick': 0,
      'percentage': 100.0,
      'color': Color(0xFFFF9800),
      'meetings': [
        {'date': '2 Sep 2025', 'status': 'Hadir', 'time': '09:03', 'topic': 'Tuhan Yang Maha Esa dan Ketuhanan'},
        {'date': '9 Sep 2025', 'status': 'Hadir', 'time': '09:05', 'topic': 'Manusia dan Agama'},
        {'date': '16 Sep 2025', 'status': 'Hadir', 'time': '09:01', 'topic': 'Hukum, HAM, dan Demokrasi'},
        {'date': '23 Sep 2025', 'status': 'Hadir', 'time': '09:07', 'topic': 'Kerukunan Antar Umat Beragama'},
        {'date': '30 Sep 2025', 'status': 'Hadir', 'time': '09:02', 'topic': 'Agama dan Ilmu Pengetahuan'},
        {'date': '7 Okt 2025', 'status': 'Hadir', 'time': '09:04', 'topic': 'Peran Umat Beragama'},
        {'date': '14 Okt 2025', 'status': 'Hadir', 'time': '09:00', 'topic': 'Agama sebagai Sumber Moral'},
      ],
    },
    {
      'name': 'Technopreneurship',
      'code': '110',
      'lecturer': 'Sunaryono,M.Kom',
      'totalMeetings': 14,
      'attended': 6,
      'absent': 1,
      'permit': 0,
      'sick': 0,
      'percentage': 85.71,
      'color': Color(0xFFF44336),
      'meetings': [
        {'date': '2 Sep 2025', 'status': 'Hadir', 'time': '10:05', 'topic': 'Konsep Dasar Technopreneurship'},
        {'date': '9 Sep 2025', 'status': 'Hadir', 'time': '10:02', 'topic': 'Inovasi dan Kreativitas'},
        {'date': '16 Sep 2025', 'status': 'Hadir', 'time': '10:08', 'topic': 'Business Model Canvas (BMC)'},
        {'date': '23 Sep 2025', 'status': 'Hadir', 'time': '10:04', 'topic': 'Value Proposition Design'},
        {'date': '30 Sep 2025', 'status': 'Alpha', 'time': '-', 'topic': 'Market Research & Validation'},
        {'date': '7 Okt 2025', 'status': 'Hadir', 'time': '10:01', 'topic': 'Pitching & Presentasi Ide'},
        {'date': '14 Okt 2025', 'status': 'Hadir', 'time': '10:06', 'topic': 'Prototyping (MVP)'},
      ],
    },
    {
      'name': 'Rangkaian Digital',
      'code': '18',
      'lecturer': 'Singgih Setia Andiko,S.Kom',
      'totalMeetings': 14,
      'attended': 5,
      'absent': 1,
      'permit': 0,
      'sick': 1,
      'percentage': 85.71,
      'color': Color(0xFF009688),
      'meetings': [
        {'date': '2 Sep 2025', 'status': 'Hadir', 'time': '13:03', 'topic': 'Sistem Bilangan'},
        {'date': '9 Sep 2025', 'status': 'Hadir', 'time': '13:05', 'topic': 'Gerbang Logika Dasar'},
        {'date': '16 Sep 2025', 'status': 'Alpha', 'time': '-', 'topic': 'Aljabar Boolean'},
        {'date': '23 Sep 2025', 'status': 'Hadir', 'time': '13:08', 'topic': 'Penyederhanaan Rangkaian'},
        {'date': '30 Sep 2025', 'status': 'Hadir', 'time': '13:02', 'topic': 'Rangkaian Kombinasional'},
        {'date': '7 Okt 2025', 'status': 'Sakit', 'time': '-', 'topic': 'Encoder & Decoder'},
        {'date': '14 Okt 2025', 'status': 'Hadir', 'time': '13:06', 'topic': 'Flip-Flop'},
      ],
    },
    {
      'name': 'Mobile Programing',
      'code': '116',
      'lecturer': 'Muhamad Aziz Setia Laksono,M.Kom',
      'totalMeetings': 14,
      'attended': 7,
      'absent': 0,
      'permit': 0,
      'sick': 0,
      'percentage': 100.0,
      'color': Color(0xFF00BCD4),
      'meetings': [
        {'date': '3 Sep 2025', 'status': 'Hadir', 'time': '08:05', 'topic': 'Intro to Mobile Dev & Flutter'},
        {'date': '10 Sep 2025', 'status': 'Hadir', 'time': '08:02', 'topic': 'Instalasi & Konfigurasi Dart'},
        {'date': '17 Sep 2025', 'status': 'Hadir', 'time': '08:09', 'topic': 'Basic Widget'},
        {'date': '24 Sep 2025', 'status': 'Hadir', 'time': '08:03', 'topic': 'Layouting: Row & Column'},
        {'date': '1 Okt 2025', 'status': 'Hadir', 'time': '08:01', 'topic': 'Stateful & Stateless Widget'},
        {'date': '8 Okt 2025', 'status': 'Hadir', 'time': '08:07', 'topic': 'Navigasi & Routing'},
        {'date': '15 Okt 2025', 'status': 'Hadir', 'time': '08:04', 'topic': 'Input & Form'},
      ],
    },
    {
      'name': 'Data Mining',
      'code': '117',
      'lecturer': 'Siti Delima Sari,M.Kom',
      'totalMeetings': 14,
      'attended': 6,
      'absent': 0,
      'permit': 1,
      'sick': 0,
      'percentage': 100.0,
      'color': Color(0xFF673AB7),
      'meetings': [
        {'date': '3 Sep 2025', 'status': 'Hadir', 'time': '10:04', 'topic': 'Pengantar Data Mining'},
        {'date': '10 Sep 2025', 'status': 'Hadir', 'time': '10:06', 'topic': 'Data Preprocessing'},
        {'date': '17 Sep 2025', 'status': 'Hadir', 'time': '10:01', 'topic': 'Konsep Klasifikasi'},
        {'date': '24 Sep 2025', 'status': 'Izin', 'time': '-', 'topic': 'Algoritma Decision Tree'},
        {'date': '1 Okt 2025', 'status': 'Hadir', 'time': '10:05', 'topic': 'Konsep Clustering'},
        {'date': '8 Okt 2025', 'status': 'Hadir', 'time': '10:02', 'topic': 'Algoritma K-Means'},
        {'date': '15 Okt 2025', 'status': 'Hadir', 'time': '10:07', 'topic': 'Konsep Asosiasi'},
      ],
    },
    {
      'name': 'Etika Profesi & Bimbingan Karir',
      'code': '127',
      'lecturer': 'Riyanti Yunita K,S.Pd,M.Kom',
      'totalMeetings': 14,
      'attended': 7,
      'absent': 0,
      'permit': 0,
      'sick': 0,
      'percentage': 100.0,
      'color': Color(0xFFE91E63),
      'meetings': [
        {'date': '4 Sep 2025', 'status': 'Hadir', 'time': '13:05', 'topic': 'Pengantar Etika Profesi'},
        {'date': '11 Sep 2025', 'status': 'Hadir', 'time': '13:02', 'topic': 'Kode Etik Profesi IT'},
        {'date': '18 Sep 2025', 'status': 'Hadir', 'time': '13:07', 'topic': 'Cyber Ethics & UU ITE'},
        {'date': '25 Sep 2025', 'status': 'Hadir', 'time': '13:03', 'topic': 'Hak Kekayaan Intelektual (HAKI)'},
        {'date': '2 Okt 2025', 'status': 'Hadir', 'time': '13:01', 'topic': 'Teknik Pembuatan CV'},
        {'date': '9 Okt 2025', 'status': 'Hadir', 'time': '13:06', 'topic': 'Strategi Wawancara Kerja'},
        {'date': '16 Okt 2025', 'status': 'Hadir', 'time': '13:04', 'topic': 'Personal Branding'},
      ],
    },
    {
      'name': 'Bahasa Indonesia',
      'code': '8',
      'lecturer': 'Uki Hares Yulianti,S.Pd,M.Pd.',
      'totalMeetings': 14,
      'attended': 6,
      'absent': 0,
      'permit': 0,
      'sick': 1,
      'percentage': 100.0,
      'color': Color(0xFF607D8B),
      'meetings': [
        {'date': '4 Sep 2025', 'status': 'Hadir', 'time': '14:03', 'topic': 'Sejarah Bahasa Indonesia'},
        {'date': '11 Sep 2025', 'status': 'Hadir', 'time': '14:05', 'topic': 'Ejaan Yang Disempurnakan (PUEBI)'},
        {'date': '18 Sep 2025', 'status': 'Hadir', 'time': '14:01', 'topic': 'Diksi dan Kalimat Efektif'},
        {'date': '25 Sep 2025', 'status': 'Sakit', 'time': '-', 'topic': 'Pengembangan Paragraf'},
        {'date': '2 Okt 2025', 'status': 'Hadir', 'time': '14:06', 'topic': 'Penulisan Karya Ilmiah'},
        {'date': '9 Okt 2025', 'status': 'Hadir', 'time': '14:02', 'topic': 'Surat Resmi & Laporan'},
        {'date': '16 Okt 2025', 'status': 'Hadir', 'time': '14:08', 'topic': 'Teknik Presentasi'},
      ],
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // --- PERHITUNGAN KESELURUHAN TELAH DIPERBAIKI ---
  double get overallAttendancePercentage {
    int totalMeetingsSoFar = 0;
    int totalCountedAsPresent = 0;

    for (var course in attendanceData) {
      // Menghitung berdasarkan pertemuan yang sudah terjadi (bukan total 14)
      final meetings = course['meetings'] as List<Map<String, dynamic>>;
      totalMeetingsSoFar += meetings.length;
      // Menghitung Hadir + Izin + Sakit sesuai aturan
      totalCountedAsPresent += (course['attended'] as int) +
          (course['permit'] as int) +
          (course['sick'] as int);
    }

    return totalMeetingsSoFar > 0
        ? (totalCountedAsPresent / totalMeetingsSoFar) * 100
        : 0;
  }

  @override
  Widget build(BuildContext context) {
    final totalCourses = attendanceData.length;
    final coursesAbove75 =
        attendanceData.where((c) => c['percentage'] >= 75).length;
    final coursesBelow75 = totalCourses - coursesAbove75;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.topRight,
            colors: [
              Color(0xFF2196F3),
              Color(0xFF1976D2),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: Icon(Icons.arrow_back, color: Colors.white),
                          onPressed: () => Navigator.pop(context),
                        ),
                        Expanded(
                          child: Text(
                            'Kehadiran',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                          ),
                          child: IconButton(
                            icon: Icon(Icons.info_outline,
                                color: Color(0xFF1976D2)),
                            onPressed: () {
                              _showAttendanceInfo();
                            },
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),

                    // Overall Attendance Card
                    Container(
                      padding: EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            blurRadius: 20,
                            offset: Offset(0, 10),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          Text(
                            'Persentase Kehadiran',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[600],
                            ),
                          ),
                          SizedBox(height: 12),
                          Stack(
                            alignment: Alignment.center,
                            children: [
                              SizedBox(
                                width: 120,
                                height: 120,
                                child: CircularProgressIndicator(
                                  value: overallAttendancePercentage / 100,
                                  strokeWidth: 12,
                                  backgroundColor: Colors.grey[200],
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    overallAttendancePercentage >= 75
                                        ? Color(0xFF4CAF50)
                                        : overallAttendancePercentage >= 50
                                            ? Color(0xFFFF9800)
                                            : Color(0xFFF44336),
                                  ),
                                ),
                              ),
                              Column(
                                children: [
                                  Text(
                                    '${overallAttendancePercentage.toStringAsFixed(1)}%',
                                    style: TextStyle(
                                      fontSize: 28,
                                      fontWeight: FontWeight.bold,
                                      color: overallAttendancePercentage >= 75
                                          ? Color(0xFF4CAF50)
                                          : overallAttendancePercentage >= 50
                                              ? Color(0xFFFF9800)
                                              : Color(0xFFF44336),
                                    ),
                                  ),
                                  Text(
                                    'Keseluruhan',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              _buildStatColumn(
                                '≥75%',
                                '$coursesAbove75',
                                Color(0xFF4CAF50),
                                'Mata Kuliah',
                              ),
                              Container(
                                height: 40,
                                width: 1,
                                color: Colors.grey[300],
                              ),
                              _buildStatColumn(
                                '<75%',
                                '$coursesBelow75',
                                Color(0xFFF44336),
                                'Mata Kuliah',
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Tabs
              Container(
                color: Colors.transparent,
                child: TabBar(
                  controller: _tabController,
                  indicatorColor: Colors.white,
                  indicatorWeight: 3,
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.white.withOpacity(0.6),
                  tabs: [
                    Tab(text: 'Per Mata Kuliah'),
                    Tab(text: 'Statistik'),
                  ],
                ),
              ),

              // Content
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.grey[50],
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildCourseListTab(),
                      _buildStatisticsTab(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatColumn(
      String label, String value, Color color, String subtitle) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
        ),
        SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          subtitle,
          style: TextStyle(
            fontSize: 11,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildCourseListTab() {
    return ListView.builder(
      padding: EdgeInsets.all(20),
      itemCount: attendanceData.length,
      itemBuilder: (context, index) {
        final course = attendanceData[index];
        return _buildCourseAttendanceCard(course);
      },
    );
  }

  Widget _buildCourseAttendanceCard(Map<String, dynamic> course) {
    final percentage = course['percentage'] as double;
    final isWarning = percentage < 75;

    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border:
            isWarning ? Border.all(color: Color(0xFFF44336), width: 2) : null,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 15,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _showCourseDetail(course),
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 5,
                      height: 60,
                      decoration: BoxDecoration(
                        color: course['color'],
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: course['color'].withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  course['code'],
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color: course['color'],
                                  ),
                                ),
                              ),
                              if (isWarning) ...[
                                SizedBox(width: 8),
                                Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Color(0xFFF44336).withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(Icons.warning,
                                          size: 12, color: Color(0xFFF44336)),
                                      SizedBox(width: 4),
                                      Text(
                                        'Rawan DO',
                                        style: TextStyle(
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                          color: Color(0xFFF44336),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ],
                          ),
                          SizedBox(height: 8),
                          Text(
                            course['name'],
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          SizedBox(height: 4),
                          Text(
                            course['lecturer'],
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Column(
                      children: [
                        Text(
                          '${percentage.toStringAsFixed(1)}%',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: percentage >= 75
                                ? Color(0xFF4CAF50)
                                : percentage >= 50
                                    ? Color(0xFFFF9800)
                                    : Color(0xFFF44336),
                          ),
                        ),
                        SizedBox(height: 4),
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 16,
                          color: Colors.grey[400],
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: _buildAttendanceStat(
                        'Hadir',
                        '${course['attended']}',
                        Color(0xFF4CAF50),
                      ),
                    ),
                    Expanded(
                      child: _buildAttendanceStat(
                        'Alpha',
                        '${course['absent']}',
                        Color(0xFFF44336),
                      ),
                    ),
                    Expanded(
                      child: _buildAttendanceStat(
                        'Izin',
                        '${course['permit']}',
                        Color(0xFF2196F3),
                      ),
                    ),
                    Expanded(
                      child: _buildAttendanceStat(
                        'Sakit',
                        '${course['sick']}',
                        Color(0xFFFF9800),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: LinearProgressIndicator(
                    value: percentage / 100,
                    minHeight: 8,
                    backgroundColor: Colors.grey[200],
                    valueColor: AlwaysStoppedAnimation<Color>(
                      percentage >= 75
                          ? Color(0xFF4CAF50)
                          : percentage >= 50
                              ? Color(0xFFFF9800)
                              : Color(0xFFF44336),
                    ),
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  '${course['meetings'].length} dari ${course['totalMeetings']} pertemuan telah berlangsung',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAttendanceStat(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 11,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildStatisticsTab() {
    int totalAttended = 0;
    int totalAbsent = 0;
    int totalPermit = 0;
    int totalSick = 0;
    int totalMeetingsSoFar = 0;

    for (var course in attendanceData) {
      totalAttended += course['attended'] as int;
      totalAbsent += course['absent'] as int;
      totalPermit += course['permit'] as int;
      totalSick += course['sick'] as int;
      totalMeetingsSoFar += (course['meetings'] as List).length;
    }

    return SingleChildScrollView(
      padding: EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Ringkasan Kehadiran',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          SizedBox(height: 16),

          // Summary Cards
          Row(
            children: [
              Expanded(
                child: _buildSummaryCard(
                  'Total Pertemuan',
                  '$totalMeetingsSoFar',
                  Icons.event,
                  Color(0xFF2196F3),
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: _buildSummaryCard(
                  'Hadir',
                  '$totalAttended',
                  Icons.check_circle,
                  Color(0xFF4CAF50),
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildSummaryCard(
                  'Alpha',
                  '$totalAbsent',
                  Icons.cancel,
                  Color(0xFFF44336),
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: _buildSummaryCard(
                  'Izin',
                  '$totalPermit',
                  Icons.info,
                  Color(0xFF2196F3),
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
          _buildSummaryCard(
            'Sakit',
            '$totalSick',
            Icons.local_hospital,
            Color(0xFFFF9800),
          ),
          SizedBox(height: 24),

          Text(
            'Distribusi Kehadiran',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          SizedBox(height: 16),

          // Distribution Chart (simplified)
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              children: [
                _buildDistributionBar(
                  'Hadir',
                  totalAttended,
                  totalMeetingsSoFar,
                  Color(0xFF4CAF50),
                ),
                SizedBox(height: 16),
                _buildDistributionBar(
                  'Alpha',
                  totalAbsent,
                  totalMeetingsSoFar,
                  Color(0xFFF44336),
                ),
                SizedBox(height: 16),
                _buildDistributionBar(
                  'Izin',
                  totalPermit,
                  totalMeetingsSoFar,
                  Color(0xFF2196F3),
                ),
                SizedBox(height: 16),
                _buildDistributionBar(
                  'Sakit',
                  totalSick,
                  totalMeetingsSoFar,
                  Color(0xFFFF9800),
                ),
              ],
            ),
          ),
          SizedBox(height: 24),

          // Ketentuan Kehadiran
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Color(0xFFFFF3E0),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Color(0xFFFF9800)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.info, color: Color(0xFFFF9800)),
                    SizedBox(width: 8),
                    Text(
                      'Ketentuan Kehadiran',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 12),
                Text(
                  '• Minimal kehadiran: 75%\n'
                  '• Kehadiran < 75% tidak dapat mengikuti ujian\n'
                  '• Izin/Sakit dihitung sebagai kehadiran\n'
                  '• Alpha tidak dihitung sebagai kehadiran',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.black87,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryCard(
      String label, String value, IconData icon, Color color) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          SizedBox(height: 12),
          Text(
            value,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          SizedBox(height: 4),
          Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDistributionBar(
      String label, int value, int total, Color color) {
    final percentage = total > 0 ? (value / total) * 100 : 0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
            ),
            Text(
              '$value (${percentage.toStringAsFixed(1)}%)',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
        SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: LinearProgressIndicator(
            value: percentage / 100,
            minHeight: 10,
            backgroundColor: Colors.grey[200],
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
        ),
      ],
    );
  }

  void _showCourseDetail(Map<String, dynamic> course) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.8,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(30),
            topRight: Radius.circular(30),
          ),
        ),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(top: 12),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 20),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: course['color'].withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          Icons.book,
                          color: course['color'],
                          size: 28,
                        ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              course['code'],
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey[600],
                              ),
                            ),
                            Text(
                              course['name'],
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87,
                              ),
                            ),
                            Text(
                              course['lecturer'],
                              style: TextStyle(
                                fontSize: 13,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Color(0xFF4CAF50).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            children: [
                              Text(
                                '${course['percentage'].toStringAsFixed(1)}%',
                                style: TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF4CAF50),
                                ),
                              ),
                              Text(
                                'Persentase',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Color(0xFF2196F3).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            children: [
                              Text(
                                '${course['attended']}/${(course['meetings'] as List).length}',
                                style: TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF2196F3),
                                ),
                              ),
                              Text(
                                'Hadir',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Riwayat Kehadiran',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      Text(
                        '${course['meetings'].length} pertemuan',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                padding: EdgeInsets.symmetric(horizontal: 24),
                itemCount: course['meetings'].length,
                itemBuilder: (context, index) {
                  final meeting = course['meetings'][index];
                  return _buildMeetingCard(meeting, index + 1);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMeetingCard(Map<String, dynamic> meeting, int meetingNumber) {
    Color statusColor;
    IconData statusIcon;

    switch (meeting['status']) {
      case 'Hadir':
        statusColor = Color(0xFF4CAF50);
        statusIcon = Icons.check_circle;
        break;
      case 'Alpha':
        statusColor = Color(0xFFF44336);
        statusIcon = Icons.cancel;
        break;
      case 'Izin':
        statusColor = Color(0xFF2196F3);
        statusIcon = Icons.info;
        break;
      case 'Sakit':
        statusColor = Color(0xFFFF9800);
        statusIcon = Icons.local_hospital;
        break;
      default:
        statusColor = Colors.grey;
        statusIcon = Icons.help;
    }

    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: statusColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: statusColor.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                '$meetingNumber',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: statusColor,
                ),
              ),
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  meeting['topic'],
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                SizedBox(height: 4),
                Row(
                  children: [
                    Icon(Icons.calendar_today,
                        size: 12, color: Colors.grey[600]),
                    SizedBox(width: 4),
                    Text(
                      meeting['date'],
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                    ),
                    if (meeting['time'] != '-') ...[
                      SizedBox(width: 12),
                      Icon(Icons.access_time,
                          size: 12, color: Colors.grey[600]),
                      SizedBox(width: 4),
                      Text(
                        meeting['time'],
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(statusIcon, size: 16, color: statusColor),
                SizedBox(width: 4),
                Text(
                  meeting['status'],
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: statusColor,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showAttendanceInfo() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.info, color: Color(0xFF2196F3)),
            SizedBox(width: 8),
            Text('Informasi Kehadiran'),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Ketentuan Kehadiran:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text('• Minimal kehadiran: 75%'),
              Text('• Kehadiran < 75% tidak dapat mengikuti ujian (DO)'),
              Text('• Izin dan Sakit dihitung sebagai kehadiran'),
              Text('• Alpha tidak dihitung sebagai kehadiran'),
              SizedBox(height: 16),
              Text(
                'Status Kehadiran:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              _buildStatusInfo(
                  'Hadir', Color(0xFF4CAF50), 'Dihitung sebagai kehadiran'),
              _buildStatusInfo('Alpha', Color(0xFFF44336),
                  'Tidak dihitung sebagai kehadiran'),
              _buildStatusInfo('Izin', Color(0xFF2196F3),
                  'Dihitung sebagai kehadiran (dengan surat)'),
              _buildStatusInfo('Sakit', Color(0xFFFF9800),
                  'Dihitung sebagai kehadiran (dengan surat)'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusInfo(String label, Color color, String description) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
                Text(
                  description,
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}