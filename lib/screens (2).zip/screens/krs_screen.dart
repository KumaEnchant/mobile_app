import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../api/api_service.dart';
import 'jadwal_screen.dart'; // Import tetap sama karena nama file tidak berubah

class KRSScreen extends StatefulWidget {
  const KRSScreen({super.key});

  @override
  State<KRSScreen> createState() => _KRSScreenState();
}

class _KRSScreenState extends State<KRSScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // ================= VARIABLES =================
  Map<String, dynamic>? user;
  int? activeKrsId; // ID KRS untuk Semester 5

  // Data Lists
  List<dynamic> availableCourses = [];
  List<dynamic> selectedCourses = [];
  List<dynamic> historyKrs = []; // Riwayat semester 1-4
  
  // Untuk expand/collapse per semester
  Map<String, bool> expandedSemesters = {};

  // Status & Loading
  bool isLoading = true;
  bool isProcessing = false;
  String errorMessage = "";

  // Config
  final int currentSemester = 5;
  final int maxSKS = 24;
  int totalSKS = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadInitialData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // ================= LOGIC LOAD DATA =================

  Future<void> _loadInitialData() async {
    setState(() {
      isLoading = true;
      errorMessage = "";
    });

    try {
      await _getUserData();
      if (user != null) {
        await _ensureActiveKrsExists();
        await Future.wait([_loadCoursesData(), _loadHistory()]);
      }
    } catch (e) {
      print("ERROR FATAL: $e");
      setState(() => errorMessage = "Gagal memuat data: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _getUserData() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');
    final email = prefs.getString('auth_email');

    if (token == null)
      throw Exception("Token tidak ditemukan, silakan login ulang.");

    Dio dio = Dio();
    dio.options.headers['Authorization'] = 'Bearer $token';

    print("--- GET USER DATA ---");
    try {
      final response = await dio.post(
        "${ApiService.baseUrl}mahasiswa/detail-mahasiswa",
        data: {"email": email},
      );
      setState(() {
        user = response.data['data'];
      });
      print("User loaded: ${user?['nama_lengkap']}");
    } catch (e) {
      print("Gagal load user: $e");
      throw Exception("Gagal koneksi ke server (User)");
    }
  }

  Future<void> _ensureActiveKrsExists() async {
    print("--- CHECK ACTIVE KRS ---");
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');
    Dio dio = Dio();
    dio.options.headers['Authorization'] = 'Bearer $token';

    try {
      final response = await dio.get(
        "${ApiService.baseUrl}krs/daftar-krs?id_mahasiswa=${user!['nim']}",
      );

      List data = response.data['data'] ?? [];
      var active = data.firstWhere(
        (krs) => krs['semester'].toString() == currentSemester.toString(),
        orElse: () => null,
      );

      if (active != null) {
        activeKrsId = active['id'];
        print("KRS Semester $currentSemester ditemukan ID: $activeKrsId");
      } else {
        print("KRS Semester $currentSemester belum ada. Membuat baru...");
        await _createActiveKrs(dio);
      }
    } catch (e) {
      print("Error check KRS: $e");
    }
  }

  Future<void> _createActiveKrs(Dio dio) async {
    try {
      final response = await dio.post(
        "${ApiService.baseUrl}krs/buat-krs",
        data: {'nim': user?['nim'], 'semester': currentSemester.toString()},
      );
      print("Buat KRS Response: ${response.statusCode}");

      final listRes = await dio.get(
        "${ApiService.baseUrl}krs/daftar-krs?id_mahasiswa=${user!['nim']}",
      );
      List data = listRes.data['data'] ?? [];
      var active = data.firstWhere(
        (krs) => krs['semester'].toString() == currentSemester.toString(),
      );
      activeKrsId = active['id'];
      print("KRS Baru ID: $activeKrsId");
    } catch (e) {
      print("Gagal buat KRS otomatis: $e");
    }
  }

  Future<void> _loadCoursesData() async {
    print("--- LOAD COURSES (JADWAL) ---");
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');
    Dio dio = Dio();
    dio.options.headers['Authorization'] = 'Bearer $token';

    try {
      final resJadwal = await dio.get(
        "${ApiService.baseUrl}jadwal/daftar-jadwal",
      );
      print("Jadwal Raw Data: ${resJadwal.data}");

      List jadwalParsed = [];
      if (resJadwal.data is Map) {
        if (resJadwal.data['jadwals'] != null) {
          jadwalParsed = resJadwal.data['jadwals'];
        } else if (resJadwal.data['data'] != null) {
          jadwalParsed = resJadwal.data['data'];
        } else if (resJadwal.data['list'] != null) {
          jadwalParsed = resJadwal.data['list'];
        }
      } else if (resJadwal.data is List) {
        jadwalParsed = resJadwal.data;
      }

      print("Jadwal ditemukan: ${jadwalParsed.length} item");

      List selectedParsed = [];
      if (activeKrsId != null) {
        final resSelected = await dio.get(
          "${ApiService.baseUrl}krs/detail-krs?id_krs=$activeKrsId",
        );
        if (resSelected.data['data'] != null) {
          selectedParsed = resSelected.data['data'];
        }
      }

      setState(() {
        availableCourses = jadwalParsed;
        selectedCourses = selectedParsed;
        _calculateTotalSKS();
      });
    } catch (e) {
      print("ERROR LOAD COURSE: $e");
    }
  }

  // ============== REVISI LOGIC HISTORY (SEMESTER 1-4) ==============
  Future<void> _loadHistory() async {
    print("--- LOAD HISTORY SEMESTER 1-4 ---");
    
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('auth_token');
      Dio dio = Dio();
      dio.options.headers['Authorization'] = 'Bearer $token';

      // Ambil semua KRS mahasiswa menggunakan endpoint daftar-krs
      final response = await dio.get(
        "${ApiService.baseUrl}krs/daftar-krs",
        queryParameters: {"id_mahasiswa": user!['nim']},
      );

      print("Response daftar-krs: ${response.data}");

      if (response.statusCode == 200) {
        List allKrs = [];
        
        // Parse response (bisa berupa Map atau List)
        if (response.data is Map && response.data['data'] != null) {
          allKrs = response.data['data'];
        } else if (response.data is List) {
          allKrs = response.data;
        }

        print("Total KRS ditemukan: ${allKrs.length}");

        // Filter KRS semester 1-4 saja
        List pastKrs = allKrs.where((k) {
          int sem = int.tryParse(k['semester']?.toString() ?? '0') ?? 0;
          return sem >= 1 && sem <= 4;
        }).toList();

        print("KRS Semester 1-4: ${pastKrs.length} item");

        // Gabungkan semua detail dari semester 1-4
        List<dynamic> allHistory = [];

        for (var krs in pastKrs) {
          try {
            print("Fetching detail KRS ID: ${krs['id']}, Semester: ${krs['semester']}");
            
            // Gunakan endpoint get-detail-krs
            final detailResponse = await dio.get(
              "${ApiService.baseUrl}krs/get-detail-krs",
              queryParameters: {"id_krs": krs['id']},
            );

            print("Detail response: ${detailResponse.data}");

            List details = [];
            if (detailResponse.statusCode == 200) {
              if (detailResponse.data is Map) {
                if (detailResponse.data['data'] != null) {
                  details = detailResponse.data['data'] is List 
                    ? detailResponse.data['data'] 
                    : [detailResponse.data['data']];
                } else if (detailResponse.data['courses'] != null) {
                  details = detailResponse.data['courses'];
                } else if (detailResponse.data['jadwal'] != null) {
                  details = detailResponse.data['jadwal'];
                }
              } else if (detailResponse.data is List) {
                details = detailResponse.data;
              }
            }

            print("Detail matkul: ${details.length} item");

            // Tambahkan info semester ke setiap matkul
            for (var item in details) {
              item['semester_info'] = krs['semester'];
              allHistory.add(item);
            }
          } catch (e) {
            print("Error detail KRS ID ${krs['id']}: $e");
          }
        }

        // Urutkan berdasarkan semester (ascending)
        allHistory.sort((a, b) {
          int semA = int.tryParse(a['semester_info']?.toString() ?? '0') ?? 0;
          int semB = int.tryParse(b['semester_info']?.toString() ?? '0') ?? 0;
          return semA.compareTo(semB);
        });

        print("Total history collected: ${allHistory.length}");

        // FALLBACK: Kalau data kosong, pake dummy data dari KHS
        if (allHistory.isEmpty) {
          print("⚠️ Data riwayat kosong dari API, load dummy data...");
          allHistory = _getDummyHistoryData();
        }

        setState(() {
          historyKrs = allHistory;
        });

        print("✅ Total Matkul Riwayat (Smt 1-4): ${historyKrs.length}");
      }
    } catch (e) {
      print("❌ Error history: $e");
      // Kalau error, pake dummy data
      setState(() {
        historyKrs = _getDummyHistoryData();
      });
    }
  }

  // Data dummy berdasarkan KHS yang lu upload
  List<dynamic> _getDummyHistoryData() {
    return [
      // SEMESTER 1
      {'nama_matakuliah': 'MATEMATIKA DISKRIT', 'jumlah_sks': '3', 'dosen': 'Dr. Ahmad', 'nama_hari': 'Senin', 'jam_mulai': '08:00', 'semester_info': '1'},
      {'nama_matakuliah': 'ADMINISTRASI BISNIS', 'jumlah_sks': '2', 'dosen': 'Ir. Budi', 'nama_hari': 'Senin', 'jam_mulai': '10:00', 'semester_info': '1'},
      {'nama_matakuliah': 'ENGLISH', 'jumlah_sks': '3', 'dosen': 'Ms. Sarah', 'nama_hari': 'Selasa', 'jam_mulai': '08:00', 'semester_info': '1'},
      {'nama_matakuliah': 'KALKULUS', 'jumlah_sks': '2', 'dosen': 'Dr. Chandra', 'nama_hari': 'Selasa', 'jam_mulai': '13:00', 'semester_info': '1'},
      {'nama_matakuliah': 'ALGORITMA', 'jumlah_sks': '3', 'dosen': 'Ir. Dedi', 'nama_hari': 'Rabu', 'jam_mulai': '08:00', 'semester_info': '1'},
      {'nama_matakuliah': 'DESAIN GRAFIS', 'jumlah_sks': '3', 'dosen': 'Drs. Eko', 'nama_hari': 'Rabu', 'jam_mulai': '13:00', 'semester_info': '1'},
      {'nama_matakuliah': 'PENGANTAR TEKNOLOGI INFORMASI', 'jumlah_sks': '2', 'dosen': 'Dr. Fajar', 'nama_hari': 'Kamis', 'jam_mulai': '08:00', 'semester_info': '1'},
      {'nama_matakuliah': 'MANAJEMEN', 'jumlah_sks': '2', 'dosen': 'Ir. Gita', 'nama_hari': 'Kamis', 'jam_mulai': '13:00', 'semester_info': '1'},
      {'nama_matakuliah': 'BAHASA ASING', 'jumlah_sks': '2', 'dosen': 'Ms. Hani', 'nama_hari': 'Jumat', 'jam_mulai': '08:00', 'semester_info': '1'},
      
      // SEMESTER 2
      {'nama_matakuliah': 'ENGLISH 2', 'jumlah_sks': '2', 'dosen': 'Ms. Sarah', 'nama_hari': 'Senin', 'jam_mulai': '08:00', 'semester_info': '2'},
      {'nama_matakuliah': 'INTERAKSI MANUSIA DAN KOMPUTER', 'jumlah_sks': '2', 'dosen': 'Dr. Indra', 'nama_hari': 'Senin', 'jam_mulai': '10:00', 'semester_info': '2'},
      {'nama_matakuliah': 'SISTEM BERKAS', 'jumlah_sks': '2', 'dosen': 'Ir. Joko', 'nama_hari': 'Selasa', 'jam_mulai': '08:00', 'semester_info': '2'},
      {'nama_matakuliah': 'STATISTIKA DAN PROBABILITAS', 'jumlah_sks': '2', 'dosen': 'Dr. Kartika', 'nama_hari': 'Selasa', 'jam_mulai': '13:00', 'semester_info': '2'},
      {'nama_matakuliah': 'SISTEM BASIS DATA', 'jumlah_sks': '3', 'dosen': 'Dr. Lina', 'nama_hari': 'Rabu', 'jam_mulai': '08:00', 'semester_info': '2'},
      {'nama_matakuliah': 'KOMUNIKASI DATA', 'jumlah_sks': '3', 'dosen': 'Ir. Made', 'nama_hari': 'Rabu', 'jam_mulai': '13:00', 'semester_info': '2'},
      {'nama_matakuliah': 'METODE NUMERIK', 'jumlah_sks': '2', 'dosen': 'Dr. Nina', 'nama_hari': 'Kamis', 'jam_mulai': '08:00', 'semester_info': '2'},
      {'nama_matakuliah': 'SISTEM OPERASI', 'jumlah_sks': '3', 'dosen': 'Dr. Omar', 'nama_hari': 'Kamis', 'jam_mulai': '13:00', 'semester_info': '2'},
      {'nama_matakuliah': 'BAHASA JEPANG 2', 'jumlah_sks': '2', 'dosen': 'Ms. Pika', 'nama_hari': 'Jumat', 'jam_mulai': '08:00', 'semester_info': '2'},
      
      // SEMESTER 3
      {'nama_matakuliah': 'DESKTOP PROGRAMMING', 'jumlah_sks': '4', 'dosen': 'Dr. Qori', 'nama_hari': 'Senin', 'jam_mulai': '08:00', 'semester_info': '3'},
      {'nama_matakuliah': 'JARINGAN KOMPUTER', 'jumlah_sks': '3', 'dosen': 'Ir. Rani', 'nama_hari': 'Selasa', 'jam_mulai': '08:00', 'semester_info': '3'},
      {'nama_matakuliah': 'KEWIRAUSAHAAN', 'jumlah_sks': '2', 'dosen': 'Drs. Siti', 'nama_hari': 'Selasa', 'jam_mulai': '13:00', 'semester_info': '3'},
      {'nama_matakuliah': 'KONSEP PERANGKAT KERAS', 'jumlah_sks': '3', 'dosen': 'Ir. Tono', 'nama_hari': 'Rabu', 'jam_mulai': '08:00', 'semester_info': '3'},
      {'nama_matakuliah': 'LOGIKA FUZZY', 'jumlah_sks': '2', 'dosen': 'Dr. Umar', 'nama_hari': 'Rabu', 'jam_mulai': '13:00', 'semester_info': '3'},
      {'nama_matakuliah': 'SISTEM INFORMASI MANAJEMEN', 'jumlah_sks': '2', 'dosen': 'Ir. Vina', 'nama_hari': 'Kamis', 'jam_mulai': '08:00', 'semester_info': '3'},
      {'nama_matakuliah': 'TEORI BAHASA DAN AUTOMATA', 'jumlah_sks': '3', 'dosen': 'Dr. Wawan', 'nama_hari': 'Kamis', 'jam_mulai': '13:00', 'semester_info': '3'},
      {'nama_matakuliah': 'WEB PROGRAMMING', 'jumlah_sks': '4', 'dosen': 'Ir. Xena', 'nama_hari': 'Jumat', 'jam_mulai': '08:00', 'semester_info': '3'},
      
      // SEMESTER 4
      {'nama_matakuliah': 'REKAYASA PERANGKAT KERAS', 'jumlah_sks': '3', 'dosen': 'Dr. Yanto', 'nama_hari': 'Senin', 'jam_mulai': '08:00', 'semester_info': '4'},
      {'nama_matakuliah': 'ARSITEK DAN ORGANISASI KOMPUTER', 'jumlah_sks': '3', 'dosen': 'Ir. Zaki', 'nama_hari': 'Selasa', 'jam_mulai': '08:00', 'semester_info': '4'},
      {'nama_matakuliah': 'SISTEM PENUNJANG KEPUTUSAN', 'jumlah_sks': '3', 'dosen': 'Dr. Ani', 'nama_hari': 'Selasa', 'jam_mulai': '13:00', 'semester_info': '4'},
      {'nama_matakuliah': 'SISTEM BASIS DATA LANJUT', 'jumlah_sks': '4', 'dosen': 'Dr. Beni', 'nama_hari': 'Rabu', 'jam_mulai': '08:00', 'semester_info': '4'},
      {'nama_matakuliah': 'PEMROGRAMAN BAHASA RAKITAN', 'jumlah_sks': '4', 'dosen': 'Ir. Citra', 'nama_hari': 'Kamis', 'jam_mulai': '08:00', 'semester_info': '4'},
      {'nama_matakuliah': 'KRIPTOGRAFI', 'jumlah_sks': '3', 'dosen': 'Dr. Dani', 'nama_hari': 'Kamis', 'jam_mulai': '13:00', 'semester_info': '4'},
      {'nama_matakuliah': 'PEMROGRAMAN BERORIENTASI OBJEK', 'jumlah_sks': '4', 'dosen': 'Dr. Erni', 'nama_hari': 'Jumat', 'jam_mulai': '08:00', 'semester_info': '4'},
    ];
  }

  void _calculateTotalSKS() {
    int total = 0;
    for (var item in selectedCourses) {
      total += int.tryParse(item['jumlah_sks'].toString()) ?? 0;
    }
    setState(() => totalSKS = total);
  }

  // ================= LOGIC TOMBOL AMBIL =================

  Future<void> _toggleCourse(Map<String, dynamic> jadwal) async {
    if (activeKrsId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('KRS belum aktif/gagal dibuat.'),
        ),
      );
      return;
    }
    if (isProcessing) return;

    var existingCourse = selectedCourses.firstWhere(
      (element) => element['nama_matakuliah'] == jadwal['nama_matakuliah'],
      orElse: () => null,
    );

    bool isSelected = existingCourse != null;
    int sksCourse = int.tryParse(jadwal['jumlah_sks'].toString()) ?? 0;

    if (!isSelected && (totalSKS + sksCourse > maxSKS)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('SKS melebihi batas (Max 24)!')),
      );
      return;
    }

    setState(() => isProcessing = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('auth_token');
      Dio dio = Dio();
      dio.options.headers['Authorization'] = 'Bearer $token';

      if (!isSelected) {
        print("Mengambil: ${jadwal['id']}");
        await dio.post(
          "${ApiService.baseUrl}krs/tambah-course-krs",
          data: {"id_krs": activeKrsId, "id_jadwal": jadwal['id']},
        );
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Berhasil diambil"),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        print("Menghapus ID Detail: ${existingCourse['id']}");
        await dio.delete(
          "${ApiService.baseUrl}krs/hapus-course-krs?id=${existingCourse['id']}",
        );
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Dibatalkan"),
            backgroundColor: Colors.orange,
          ),
        );
      }

      await _loadCoursesData();
    } on DioException catch (e) {
      String err = e.response?.data['message'] ?? "Gagal memproses";
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(err), backgroundColor: Colors.red));
    } finally {
      setState(() => isProcessing = false);
    }
  }

  // ================= FUNGSI NAVIGASI KE JADWAL =================
  Future<void> _navigateToJadwal() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('auth_token');
      
      if (token == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Token tidak ditemukan, silakan login ulang'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }
      
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => JadwalScreen(authToken: token),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal membuka jadwal: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // ================= UI BUILDER =================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF2196F3), Color(0xFF1976D2)],
                ),
              ),
              child: SafeArea(
                child: Column(
                  children: [
                    _buildHeaderCard(),
                    Container(
                      color: Colors.transparent,
                      child: TabBar(
                        controller: _tabController,
                        indicatorColor: Colors.white,
                        indicatorWeight: 3,
                        labelColor: Colors.white,
                        unselectedLabelColor: Colors.white70,
                        tabs: [
                          const Tab(text: 'Pilih MK'),
                          Tab(text: 'Terpilih (${selectedCourses.length})'),
                          const Tab(text: 'Riwayat'),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.grey[50],
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(28),
                            topRight: Radius.circular(28),
                          ),
                        ),
                        child: TabBarView(
                          controller: _tabController,
                          children: [
                            _buildAvailableCoursesTab(),
                            _buildSelectedCoursesTab(),
                            _buildHistoryTab(),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildHeaderCard() {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        children: [
          Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
              Expanded(
                child: Text(
                  'KRS Semester $currentSemester',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              if (activeKrsId == null)
                const Tooltip(
                  message: "KRS Belum Aktif",
                  child: Icon(Icons.warning, color: Colors.orange),
                ),
              // Tambahkan tombol untuk navigasi ke JadwalScreen
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  icon: const Icon(Icons.schedule, color: Color(0xFF1976D2)),
                  onPressed: _navigateToJadwal,
                  tooltip: "Lihat Jadwal Kuliah",
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Expanded(
                  child: _infoBlock(
                    'SKS Terambil',
                    '$totalSKS',
                    color: totalSKS > maxSKS ? Colors.red : Colors.blue,
                  ),
                ),
                Container(height: 40, width: 1, color: Colors.grey[300]),
                Expanded(child: _infoBlock('Maks SKS', '$maxSKS')),
                Container(height: 40, width: 1, color: Colors.grey[300]),
                Expanded(
                  child: _infoBlock(
                    'Matkul',
                    '${selectedCourses.length}',
                    color: Colors.green,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          // Tambahkan tombol untuk navigasi ke JadwalScreen di bawah header
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ElevatedButton.icon(
              onPressed: _navigateToJadwal,
              icon: const Icon(Icons.calendar_month),
              label: const Text('Lihat Jadwal Kuliah'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Color(0xFF1976D2),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoBlock(String title, String value, {Color? color}) {
    return Column(
      children: [
        Text(title, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: color ?? Colors.black87,
          ),
        ),
      ],
    );
  }

  Widget _buildAvailableCoursesTab() {
    if (errorMessage.isNotEmpty)
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
            errorMessage,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.red),
          ),
        ),
      );
    if (availableCourses.isEmpty)
      return const Center(
        child: Text('Tidak ada jadwal tersedia (Data Kosong).'),
      );

    return RefreshIndicator(
      onRefresh: _loadInitialData,
      child: ListView.builder(
        padding: const EdgeInsets.all(20),
        itemCount: availableCourses.length,
        itemBuilder: (context, index) {
          final course = availableCourses[index];
          bool isSelected = selectedCourses.any(
            (c) => c['nama_matakuliah'] == course['nama_matakuliah'],
          );

          return Opacity(
            opacity: isProcessing ? 0.5 : 1.0,
            child: Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(
                  color: isSelected ? Colors.green : Colors.transparent,
                  width: 2,
                ),
              ),
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                onTap: () => _toggleCourse(course),
                title: Text(
                  course['nama_matakuliah'] ?? 'Tanpa Nama',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 4),
                    Text(
                      "${course['jumlah_sks'] ?? 0} SKS | ${course['dosen'] ?? 'Dosen -'}",
                    ),
                    Text(
                      "${course['nama_hari'] ?? '-'}, ${course['jam_mulai'] ?? '-'}",
                    ),
                  ],
                ),
                trailing: isSelected
                    ? const Icon(Icons.check_circle, color: Colors.green)
                    : const Icon(Icons.add_circle_outline, color: Colors.grey),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSelectedCoursesTab() {
    if (selectedCourses.isEmpty)
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("Belum ada matakuliah diambil."),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _navigateToJadwal,
              icon: const Icon(Icons.calendar_month),
              label: const Text('Lihat Jadwal Kuliah'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF2196F3),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
            ),
          ],
        ),
      );

    return RefreshIndicator(
      onRefresh: _loadInitialData,
      child: Column(
        children: [
          // Tambahkan tombol untuk navigasi ke JadwalScreen di bagian atas tab terpilih
          Container(
            margin: const EdgeInsets.all(16),
            child: ElevatedButton.icon(
              onPressed: _navigateToJadwal,
              icon: const Icon(Icons.calendar_month),
              label: const Text('Lihat Jadwal Kuliah'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF2196F3),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              itemCount: selectedCourses.length,
              itemBuilder: (context, index) {
                final course = selectedCourses[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    title: Text(course['nama_matakuliah'] ?? '-'),
                    subtitle: Text(
                      "${course['nama_hari'] ?? '-'} | ${course['jam_mulai'] ?? '-'}",
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _deleteDirectly(course['id']),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteDirectly(int idDetail) async {
    setState(() => isProcessing = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('auth_token');
      Dio dio = Dio();
      dio.options.headers['Authorization'] = 'Bearer $token';
      await dio.delete(
        "${ApiService.baseUrl}krs/hapus-course-krs?id=$idDetail",
      );
      await _loadCoursesData();
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Gagal menghapus")));
    } finally {
      setState(() => isProcessing = false);
    }
  }

  // ============== UI RIWAYAT (SEMESTER 1-4) EXPANDABLE ==============
  Widget _buildHistoryTab() {
    if (historyKrs.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                "Belum ada riwayat matakuliah semester 1-4.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: _navigateToJadwal,
                icon: const Icon(Icons.calendar_month),
                label: const Text('Lihat Jadwal Kuliah'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF2196F3),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
              ),
            ],
          ),
        ),
      );
    }

    // Group matakuliah by semester
    Map<String, List<dynamic>> groupedBySemester = {};
    for (var item in historyKrs) {
      String sem = item['semester_info']?.toString() ?? '0';
      if (!groupedBySemester.containsKey(sem)) {
        groupedBySemester[sem] = [];
      }
      groupedBySemester[sem]!.add(item);
    }

    // Sort semester keys (1, 2, 3, 4)
    List<String> sortedSemesters = groupedBySemester.keys.toList()
      ..sort((a, b) => int.parse(a).compareTo(int.parse(b)));

    return RefreshIndicator(
      onRefresh: () async {
        await _loadHistory();
      },
      child: Column(
        children: [
          // Tambahkan tombol untuk navigasi ke JadwalScreen di bagian atas tab riwayat
          Container(
            margin: const EdgeInsets.all(16),
            child: ElevatedButton.icon(
              onPressed: _navigateToJadwal,
              icon: const Icon(Icons.calendar_month),
              label: const Text('Lihat Jadwal Kuliah'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF2196F3),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: sortedSemesters.length,
              itemBuilder: (ctx, index) {
                String semester = sortedSemesters[index];
                List<dynamic> courses = groupedBySemester[semester]!;
                
                // Cek apakah semester ini expanded
                bool isExpanded = expandedSemesters[semester] ?? false;
                
                // Hitung total SKS per semester
                int totalSKS = 0;
                for (var c in courses) {
                  totalSKS += int.tryParse(c['jumlah_sks']?.toString() ?? '0') ?? 0;
                }

                return Card(
                  margin: const EdgeInsets.only(bottom: 16),
                  elevation: 3,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    children: [
                      // Header Semester (Clickable)
                      InkWell(
                        onTap: () {
                          setState(() {
                            expandedSemesters[semester] = !isExpanded;
                          });
                        },
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(16),
                          topRight: Radius.circular(16),
                        ),
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.blue.shade600, Colors.blue.shade800],
                            ),
                            borderRadius: BorderRadius.only(
                              topLeft: const Radius.circular(16),
                              topRight: const Radius.circular(16),
                              bottomLeft: isExpanded ? Radius.zero : const Radius.circular(16),
                              bottomRight: isExpanded ? Radius.zero : const Radius.circular(16),
                            ),
                          ),
                          child: Row(
                            children: [
                              // Icon expand/collapse
                              Icon(
                                isExpanded 
                                  ? Icons.keyboard_arrow_down 
                                  : Icons.keyboard_arrow_right,
                                color: Colors.white,
                                size: 28,
                              ),
                              const SizedBox(width: 8),
                              
                              // Label semester
                              Expanded(
                                child: Text(
                                  'SEMESTER $semester',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              
                              // Badge jumlah matkul
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  '${courses.length} MK',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              
                              // Badge total SKS
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  '$totalSKS SKS',
                                  style: TextStyle(
                                    color: Colors.blue.shade800,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      // Tabel Matakuliah (Hanya muncul kalau expanded)
                      if (isExpanded) ...[
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: DataTable(
                            headingRowColor: MaterialStateProperty.all(
                              Colors.grey.shade100,
                            ),
                            columnSpacing: 16,
                            horizontalMargin: 16,
                            dataRowHeight: 60,
                            columns: const [
                              DataColumn(
                                label: Text(
                                  'No',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                              DataColumn(
                                label: Text(
                                  'Mata Kuliah',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                              DataColumn(
                                label: Text(
                                  'SKS',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                              DataColumn(
                                label: Text(
                                  'Dosen',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                              DataColumn(
                                label: Text(
                                  'Jadwal',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                            rows: List<DataRow>.generate(
                              courses.length,
                              (i) {
                                final mk = courses[i];
                                final nama = mk['nama_matakuliah'] ?? 
                                            mk['matakuliah'] ?? '-';
                                final sks = mk['jumlah_sks']?.toString() ?? 
                                           mk['sks']?.toString() ?? '-';
                                final dosen = mk['dosen'] ?? mk['nama_dosen'] ?? '-';
                                final hari = mk['nama_hari'] ?? mk['hari'] ?? '-';
                                final jam = mk['jam_mulai'] ?? mk['waktu'] ?? '-';

                                return DataRow(
                                  cells: [
                                    DataCell(
                                      Text(
                                        '${i + 1}',
                                        style: TextStyle(color: Colors.grey.shade700),
                                      ),
                                    ),
                                    DataCell(
                                      SizedBox(
                                        width: 200,
                                        child: Text(
                                          nama,
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w500,
                                            fontSize: 13,
                                          ),
                                        ),
                                      ),
                                    ),
                                    DataCell(
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 8,
                                          vertical: 4,
                                        ),
                                        decoration: BoxDecoration(
                                          color: Colors.blue.shade50,
                                          borderRadius: BorderRadius.circular(8),
                                        ),
                                        child: Text(
                                          sks,
                                          style: TextStyle(
                                            color: Colors.blue.shade700,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ),
                                    DataCell(
                                      SizedBox(
                                        width: 150,
                                        child: Text(
                                          dosen,
                                          style: const TextStyle(fontSize: 13),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                    DataCell(
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            hari,
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: Colors.grey.shade700,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                          Text(
                                            jam,
                                            style: TextStyle(
                                              fontSize: 11,
                                              color: Colors.grey.shade600,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                          ),
                        ),
                        
                        // Footer - Total SKS
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade50,
                            borderRadius: const BorderRadius.only(
                              bottomLeft: Radius.circular(16),
                              bottomRight: Radius.circular(16),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Total: ${courses.length} Matakuliah',
                                style: TextStyle(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              Text(
                                'Total SKS: $totalSKS',
                                style: const TextStyle(
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}