import 'package:flutter/material.dart';

class KHSScreen extends StatefulWidget {
  const KHSScreen({super.key});

  @override
  State<KHSScreen> createState() => _KHSScreenState();
}

class _KHSScreenState extends State<KHSScreen> {
  int selectedSemester = 5; // Default semester aktif

  // Definisikan warna utama agar konsisten
  final Color primaryColor = Color(0xFF2196F3);
  final Color primaryColorDark = Color(0xFF1976D2);

  // --- DATA KHS DENGAN TAHUN AKADEMIK YANG SUDAH DIPERBAIKI ---
  final Map<int, Map<String, dynamic>> khsData = {
    1: {
      'semester': 'Semester 1',
      'year': 'Ganjil 2023/2024', // <-- Diperbarui
      'ips': 3.73,
      'ipk': 3.73,
      'totalSks': 22,
      'sksTempuh': 22,
      'courses': [
        {'code': 'STI110122001', 'name': 'MATEMATIKA DISKRIT', 'credits': 3, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI110122006', 'name': 'ADMINISTRASI BISNIS', 'credits': 2, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI110122005', 'name': 'ENGLISH', 'credits': 3, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI110122007', 'name': 'KALKULUS', 'credits': 2, 'grade': 'B', 'quality': 3.0},
        {'code': 'STI110122002', 'name': 'ALGORITMA', 'credits': 3, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI110122009', 'name': 'DESAIN GRAFIS', 'credits': 3, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI110122003', 'name': 'PENGANTAR TEKNOLOGI INFORMASI', 'credits': 2, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI110122004', 'name': 'MANAJEMEN', 'credits': 2, 'grade': 'B', 'quality': 3.0},
        {'code': 'STI110122008', 'name': 'BAHASA ASING', 'credits': 2, 'grade': 'B', 'quality': 3.0},
      ],
    },
    2: {
      'semester': 'Semester 2',
      'year': 'Genap 2023/2024', // <-- Diperbarui
      'ips': 3.81,
      'ipk': 3.77,
      'totalSks': 43,
      'sksTempuh': 21,
      'courses': [
        {'code': 'STI110222002', 'name': 'ENGLISH 2', 'credits': 2, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI102BS06', 'name': 'INTERAKSI MANUSIA DAN KOMPUTER', 'credits': 2, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI102BS09', 'name': 'SISTEM BERKAS', 'credits': 2, 'grade': 'B', 'quality': 3.0},
        {'code': 'STI104BS05', 'name': 'STATISTIKA DAN PROBABILITAS', 'credits': 2, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI102BS03', 'name': 'SISTEM BASIS DATA', 'credits': 3, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI102BS04', 'name': 'KOMUNIKASI DATA', 'credits': 3, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI101BS10', 'name': 'METODE NUMERIK', 'credits': 2, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI102BS10', 'name': 'SISTEM OPERASI', 'credits': 3, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI110222001', 'name': 'BAHASA JEPANG 2', 'credits': 2, 'grade': 'B', 'quality': 3.0},
      ],
    },
    3: {
      'semester': 'Semester 3',
      'year': 'Ganjil 2024/2025', // <-- Disesuaikan
      'ips': 3.74,
      'ipk': 3.76,
      'totalSks': 66,
      'sksTempuh': 23,
      'courses': [
        {'code': 'STI1103002', 'name': 'DESKTOP PROGRAMMING', 'credits': 4, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI1103003', 'name': 'JARINGAN KOMPUTER', 'credits': 3, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI1103001', 'name': 'KEWIRAUSAHAAN', 'credits': 2, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI1103004', 'name': 'KONSEP PERANGKAT KERAS', 'credits': 3, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI1103007', 'name': 'LOGIKA FUZZY', 'credits': 2, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI1103005', 'name': 'SISTEM INFORMASI MANAJEMEN', 'credits': 2, 'grade': 'B', 'quality': 3.0},
        {'code': 'STI1103006', 'name': 'TEORI BAHASA DAN AUTOMATA', 'credits': 3, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI1103008', 'name': 'WEB PROGRAMMING', 'credits': 4, 'grade': 'B', 'quality': 3.0},
      ],
    },
    4: {
      'semester': 'Semester 4',
      'year': 'Genap 2024/2025', // <-- Disesuaikan
      'ips': 3.88,
      'ipk': 3.79,
      'totalSks': 90,
      'sksTempuh': 24,
      'courses': [
        {'code': 'STI104BS02', 'name': 'REKAYASA PERANGKAT KERAS', 'credits': 3, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI104BS03', 'name': 'ARSITEK DAN ORGANISASI KOMPUTER', 'credits': 3, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI110425001', 'name': 'SISTEM PENUNJANG KEPUTUSAN', 'credits': 3, 'grade': 'B', 'quality': 3.0},
        {'code': 'STI104BS04', 'name': 'SISTEM BASIS DATA LANJUT', 'credits': 4, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI110425002', 'name': 'PEMROGRAMAN BAHASA RAKITAN', 'credits': 4, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI104BS06', 'name': 'KRIPTOGRAFI', 'credits': 3, 'grade': 'A', 'quality': 4.0},
        {'code': 'STI104BS01', 'name': 'PEMROGRAMAN BERORIENTASI OBJEK', 'credits': 4, 'grade': 'A', 'quality': 4.0},
      ],
    },
    5: {
      'semester': 'Semester 5',
      'year': 'Ganjil 2025/2026',
      'ips': 0.00, // Nilai belum keluar
      'ipk': 3.79, // IPK dari semester sebelumnya
      'totalSks': 114, // SKS akumulatif jika semester 5 selesai
      'sksTempuh': 24, // SKS semester berjalan
      'courses': [
        {'code': 'STI11052401', 'name': 'KEWARGANEGARAAN', 'credits': 2, 'grade': '-', 'quality': 0.0},
        {'code': 'STI11052403', 'name': 'MANAJEMEN BISNIS', 'credits': 2, 'grade': '-', 'quality': 0.0},
        {'code': 'STI11052402', 'name': 'AGAMA', 'credits': 2, 'grade': '-', 'quality': 0.0},
        {'code': 'STI11052407', 'name': 'RANGKAIAN DIGITAL', 'credits': 3, 'grade': '-', 'quality': 0.0},
        {'code': 'STI11052405', 'name': 'TECHNOPRENEURSHIP', 'credits': 2, 'grade': '-', 'quality': 0.0},
        {'code': 'STI11052410', 'name': 'MOBILE PROGRAMMING', 'credits': 4, 'grade': '-', 'quality': 0.0},
        {'code': 'STI11052409', 'name': 'DATA MINING', 'credits': 3, 'grade': '-', 'quality': 0.0},
        {'code': 'STI11052404', 'name': 'PANCASILA', 'credits': 2, 'grade': '-', 'quality': 0.0},
        {'code': 'STI11052406', 'name': 'ETIKA PROFESI DAN BIMBINGAN KARIR', 'credits': 2, 'grade': '-', 'quality': 0.0},
        {'code': 'STI11052408', 'name': 'BAHASA INDONESIA', 'credits': 2, 'grade': '-', 'quality': 0.0},
      ],
    },
  };

  @override
  Widget build(BuildContext context) {
    final Map<String, dynamic> summaryKHS = khsData[4]!; 
    final Map<String, dynamic> currentKHS = khsData[selectedSemester]!;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.topRight,
            colors: [
              primaryColor,
              primaryColorDark,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(context),
              _buildIPKCard(summaryKHS, currentKHS), 
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.grey[50],
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  child: Column(
                    children: [
                      _buildSemesterSelector(),
                      Expanded(child: _buildCoursesList(currentKHS)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomBar(context),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Row(
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
            child: IconButton(
              icon: Icon(Icons.arrow_back, color: primaryColorDark),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Kartu Hasil Studi',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'OHman',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
            child: IconButton(
              icon: Icon(Icons.download, color: primaryColorDark),
              onPressed: () {
                _showDownloadDialog(context);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIPKCard(Map<String, dynamic> summaryKHS, Map<String, dynamic> currentKHS) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20),
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildIPKItem(
                'IPK',
                summaryKHS['ipk'].toStringAsFixed(2),
                Color(0xFF4CAF50),
                Icons.trending_up,
              ),
              Container(height: 60, width: 1, color: Colors.grey[300]),
              _buildIPKItem(
                'IPS',
                currentKHS['ips'] == 0.00 ? '---' : currentKHS['ips'].toStringAsFixed(2),
                Color(0xFF2196F3),
                Icons.star,
              ),
              Container(height: 60, width: 1, color: Colors.grey[300]),
              _buildIPKItem(
                'Total SKS',
                summaryKHS['totalSks'].toString(),
                Color(0xFF9C27B0),
                Icons.credit_card,
              ),
            ],
          ),
          SizedBox(height: 16),
          Divider(),
          SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildStatItem('Semester Aktif', '5 Ganjil'),
              _buildStatItem('SKS Semester Ini', '${currentKHS['sksTempuh']} SKS'),
              _buildStatItem('Status', 'Aktif'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildIPKItem(String label, String value, Color color, IconData icon) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: color, size: 24),
        ),
        SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildStatItem(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            fontSize: 11,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildSemesterSelector() {
    return Container(
      height: 80,
      padding: EdgeInsets.symmetric(vertical: 16),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 20),
        itemCount: khsData.length,
        itemBuilder: (context, index) {
          final semester = index + 1;
          final isSelected = semester == selectedSemester;
          final ips = khsData[semester]!['ips'] as double;
          
          return GestureDetector(
            onTap: () {
              setState(() {
                selectedSemester = semester;
              });
            },
            child: Container(
              margin: EdgeInsets.only(right: 12),
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              decoration: BoxDecoration(
                color: isSelected ? primaryColorDark : Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Semester $semester',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: isSelected ? Colors.white : Colors.black87,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    ips == 0.00 ? 'IPS: ---' : 'IPS: ${ips.toStringAsFixed(2)}',
                    style: TextStyle(
                      fontSize: 11,
                      color: isSelected
                          ? Colors.white.withOpacity(0.9)
                          : Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildCoursesList(Map<String, dynamic> khs) {
    final courses = khs['courses'] as List<Map<String, dynamic>>;

    return SingleChildScrollView(
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${khs['semester']} - ${khs['year']}',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Color(0xFF4CAF50).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '${courses.length} Mata Kuliah',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF4CAF50),
                    ),
                  ),
                ),
              ],
            ),
          ),
          ListView.builder(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            itemCount: courses.length,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              final course = courses[index];
              return _buildCourseCard(course);
            },
          ),
          _buildSummaryCard(khs),
        ],
      ),
    );
  }

  Widget _buildCourseCard(Map<String, dynamic> course) {
    final bool isCurrentSemester = course['grade'] == '-';
    Color gradeColor;

    if (isCurrentSemester) {
      gradeColor = Colors.grey;
    } else if (course['grade'].startsWith('A')) {
      gradeColor = Color(0xFF4CAF50);
    } else if (course['grade'].startsWith('B')) {
      gradeColor = Color(0xFF2196F3);
    } else if (course['grade'].startsWith('C')) {
      gradeColor = Color(0xFFFF9800);
    } else {
      gradeColor = Color(0xFFF44336);
    }

    return Container(
      margin: EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: InkWell(
        onTap: () {
          if (!isCurrentSemester) {
             _showCourseDetailDialog(course);
          }
        },
        borderRadius: BorderRadius.circular(15),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: gradeColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: isCurrentSemester
                      ? Icon(Icons.schedule, color: gradeColor, size: 24)
                      : Text(
                          course['grade'],
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: gradeColor,
                          ),
                        ),
                ),
              ),
              SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      course['code'],
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey[600],
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      course['name'],
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 8),
                     Row(
                      children: [
                        _buildCourseInfo(Icons.credit_card, '${course['credits']} SKS'),
                        if(!isCurrentSemester) ...[
                          SizedBox(width: 16),
                          _buildCourseInfo(Icons.star, 'Bobot: ${course['quality']}'),
                        ]
                      ],
                    ),
                  ],
                ),
              ),
              if(!isCurrentSemester)
                Icon(
                  Icons.chevron_right,
                  color: Colors.grey[400],
                  size: 24,
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCourseInfo(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, size: 14, color: Colors.grey[600]),
        SizedBox(width: 4),
        Text(
          text,
          style: TextStyle(fontSize: 12, color: Colors.grey[600]),
        ),
      ],
    );
  }

  Widget _buildSummaryCard(Map<String, dynamic> khs) {
    return Container(
      margin: EdgeInsets.all(20),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Ringkasan Semester',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          SizedBox(height: 12),
          Divider(),
          SizedBox(height: 12),
          _buildSummaryRow('SKS Diambil', '${khs['sksTempuh']} SKS'),
          SizedBox(height: 8),
          _buildSummaryRow('IP Semester', khs['ips'] == 0.00 ? '---' : khs['ips'].toStringAsFixed(2)),
          SizedBox(height: 8),
          _buildSummaryRow('IPK Kumulatif', khs['ipk'].toStringAsFixed(2)),
        ],
      ),
    );
  }
  
  Widget _buildSummaryRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey[700],
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
      ],
    );
  }

  Widget _buildBottomBar(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () {
                  _showGradeStatistics(context);
                },
                icon: Icon(Icons.bar_chart),
                label: Text('Statistik'),
                style: OutlinedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  side: BorderSide(color: primaryColorDark),
                  foregroundColor: primaryColorDark,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
            SizedBox(width: 12),
            Expanded(
              child: ElevatedButton.icon(
                onPressed: () {
                  _showDownloadDialog(context);
                },
                icon: Icon(Icons.download),
                label: Text('Cetak Transkrip'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColorDark,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showCourseDetailDialog(Map<String, dynamic> course) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: Text('Detail Nilai'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailRow('Kode', course['code']),
            Divider(),
            _buildDetailRow('Mata Kuliah', course['name']),
            Divider(),
            _buildDetailRow('SKS', '${course['credits']}'),
            Divider(),
            _buildDetailRow('Nilai Huruf', course['grade']),
            Divider(),
            _buildDetailRow('Bobot', '${course['quality']}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontSize: 14, color: Colors.grey[700])),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87),
            ),
          ),
        ],
      ),
    );
  }

  void _showDownloadDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: Row(
          children: [
            Icon(Icons.download, color: primaryColor),
            SizedBox(width: 8),
            Text('Download Transkrip'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.picture_as_pdf, color: primaryColorDark),
              title: Text('Download PDF'),
              subtitle: Text('Transkrip dalam format PDF'),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                      content: Text('Mengunduh transkrip PDF...'),
                      behavior: SnackBarBehavior.floating),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.table_chart, color: Color(0xFF4CAF50)),
              title: Text('Download Excel'),
              subtitle: Text('Transkrip dalam format Excel'),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                      content: Text('Mengunduh transkrip Excel...'),
                      behavior: SnackBarBehavior.floating),
                );
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Batal'),
          ),
        ],
      ),
    );
  }

  void _showGradeStatistics(BuildContext context) {
    int totalCourses = 0;
    int gradeA = 0, gradeB = 0, gradeC = 0, gradeD = 0;

    khsData.forEach((semester, data) {
      if (semester == 5) return; // Jangan hitung semester 5
      final courses = data['courses'] as List<Map<String, dynamic>>;
      totalCourses += courses.length;

      for (var course in courses) {
        final grade = course['grade'] as String;
        if (grade.startsWith('A'))
          gradeA++;
        else if (grade.startsWith('B'))
          gradeB++;
        else if (grade.startsWith('C'))
          gradeC++;
        else
          gradeD++;
      }
    });

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: Row(
          children: [
            Icon(Icons.bar_chart, color: primaryColor),
            SizedBox(width: 8),
            Text('Statistik Nilai'),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Distribusi Nilai',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87)),
              SizedBox(height: 16),
              _buildGradeBar('A', gradeA, totalCourses, Color(0xFF4CAF50)),
              SizedBox(height: 12),
              _buildGradeBar('B', gradeB, totalCourses, Color(0xFF2196F3)),
              SizedBox(height: 12),
              _buildGradeBar('C', gradeC, totalCourses, Color(0xFFFF9800)),
              SizedBox(height: 12),
              _buildGradeBar('D', gradeD, totalCourses, Color(0xFFF44336)),
              SizedBox(height: 20),
              Divider(),
              SizedBox(height: 16),
              Text('Perkembangan IPK',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87)),
              SizedBox(height: 16),
              ...List.generate(khsData.length, (index) {
                final semester = index + 1;
                final ipk = khsData[semester]!['ipk'];
                if (ipk == null) return Container();
                return Padding(
                  padding: EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      SizedBox(
                          width: 80,
                          child: Text('Semester $semester',
                              style: TextStyle(fontSize: 12))),
                      Expanded(
                        child: Container(
                          height: 24,
                          decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(12)),
                          child: FractionallySizedBox(
                            alignment: Alignment.centerLeft,
                            widthFactor: (ipk as double) / 4.0,
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  Color(0xFF4CAF50),
                                  Color(0xFF2E7D32)
                                ]),
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 8),
                      SizedBox(
                          width: 40,
                          child: Text((ipk as double).toStringAsFixed(2),
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12))),
                    ],
                  ),
                );
              }),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Widget _buildGradeBar(String grade, int count, int total, Color color) {
    double percentage = total > 0 ? (count / total) * 100 : 0.0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Nilai $grade',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey[700])),
            Text('$count (${percentage.toStringAsFixed(1)}%)',
                style: TextStyle(
                    fontSize: 12, fontWeight: FontWeight.bold, color: color)),
          ],
        ),
        SizedBox(height: 6),
        Container(
          height: 10,
          decoration: BoxDecoration(
              color: Colors.grey[200], borderRadius: BorderRadius.circular(5)),
          child: FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: total > 0 ? count / total : 0,
            child: Container(
              decoration: BoxDecoration(
                  color: color, borderRadius: BorderRadius.circular(5)),
            ),
          ),
        ),
      ],
    );
  }
}