import 'package:flutter/material.dart';

class KRSScreen extends StatefulWidget {
  const KRSScreen({super.key});

  @override
  State<KRSScreen> createState() => _KRSScreenState();
}

class _KRSScreenState extends State<KRSScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int totalSKS = 0;
  int maxSKS = 24;
  List<Map<String, dynamic>> selectedCourses = [];
  
  // Status periode KRS
  bool isKRSPeriodActive = false; // Ubah ke true saat periode KRS aktif
  String krsStatus = 'DITUTUP'; // DIBUKA, DITUTUP
  String krsPeriodMessage = 'Periode pengisian KRS telah ditutup. Silakan tunggu periode berikutnya.';

  // Data mata kuliah yang tersedia
  final List<Map<String, dynamic>> availableCourses = [
    {
      'code': 'TIF501',
      'name': 'Pemrograman Mobile Lanjut',
      'credits': 3,
      'semester': 5,
      'lecturer': 'Dr. Ahmad Susanto',
      'schedule': 'Senin, 08:00 - 10:00',
      'room': 'Lab 301',
      'capacity': 40,
      'enrolled': 28,
      'prerequisite': 'TIF401',
      'isSelected': false,
    },
    {
      'code': 'TIF502',
      'name': 'Kecerdasan Buatan',
      'credits': 3,
      'semester': 5,
      'lecturer': 'Dr. Fitri Handayani',
      'schedule': 'Kamis, 10:00 - 12:00',
      'room': 'Lab 303',
      'capacity': 35,
      'enrolled': 30,
      'prerequisite': 'TIF301',
      'isSelected': false,
    },
    {
      'code': 'TIF503',
      'name': 'Keamanan Sistem Informasi',
      'credits': 3,
      'semester': 5,
      'lecturer': 'M. Gandi Pratama',
      'schedule': 'Jumat, 08:00 - 10:00',
      'room': 'R. 401',
      'capacity': 40,
      'enrolled': 25,
      'prerequisite': 'TIF402',
      'isSelected': false,
    },
    {
      'code': 'TIF504',
      'name': 'Data Mining',
      'credits': 3,
      'semester': 5,
      'lecturer': 'Prof. Eko Prasetyo',
      'schedule': 'Selasa, 13:00 - 15:00',
      'room': 'Lab 302',
      'capacity': 30,
      'enrolled': 20,
      'prerequisite': 'TIF302',
      'isSelected': false,
    },
    {
      'code': 'TIF505',
      'name': 'Internet of Things',
      'credits': 3,
      'semester': 5,
      'lecturer': 'Ir. Budi Santoso',
      'schedule': 'Rabu, 10:00 - 12:00',
      'room': 'Lab 201',
      'capacity': 35,
      'enrolled': 32,
      'prerequisite': 'TIF403',
      'isSelected': false,
    },
    {
      'code': 'TIF506',
      'name': 'Cloud Computing',
      'credits': 3,
      'semester': 5,
      'lecturer': 'M. Chandra Wijaya',
      'schedule': 'Senin, 13:00 - 15:00',
      'room': 'Lab 304',
      'capacity': 30,
      'enrolled': 18,
      'prerequisite': 'TIF404',
      'isSelected': false,
    },
    {
      'code': 'TIF507',
      'name': 'Manajemen Proyek TI',
      'credits': 2,
      'semester': 5,
      'lecturer': 'Drs. Dedi Hermawan',
      'schedule': 'Kamis, 13:00 - 15:00',
      'room': 'R. 301',
      'capacity': 40,
      'enrolled': 35,
      'prerequisite': '-',
      'isSelected': false,
    },
    {
      'code': 'TIF508',
      'name': 'Pengolahan Citra Digital',
      'credits': 3,
      'semester': 5,
      'lecturer': 'Dr. Hesti Wulandari',
      'schedule': 'Rabu, 08:00 - 10:00',
      'room': 'Lab 305',
      'capacity': 30,
      'enrolled': 22,
      'prerequisite': 'TIF301',
      'isSelected': false,
    },
  ];

  // Data KRS yang sudah disetujui (riwayat)
  final List<Map<String, dynamic>> approvedKRS = [
    {
      'semester': 'Semester 4 - 2023/2024',
      'totalCredits': 21,
      'status': 'Disetujui',
      'approvalDate': '15 Agustus 2024',
      'approvedBy': 'NILA AYU A. S.S, M.Pd',
    },
    {
      'semester': 'Semester 3 - 2023/2024',
      'totalCredits': 20,
      'status': 'Disetujui',
      'approvalDate': '10 Februari 2024',
      'approvedBy': 'Riyanti Yunita K,S.Pd,M.Kom',
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _toggleCourse(int index) {
    setState(() {
      availableCourses[index]['isSelected'] = !availableCourses[index]['isSelected'];
      
      if (availableCourses[index]['isSelected']) {
        selectedCourses.add(availableCourses[index]);
        totalSKS += availableCourses[index]['credits'] as int;
      } else {
        selectedCourses.remove(availableCourses[index]);
        totalSKS -= availableCourses[index]['credits'] as int;
      }
    });
  }

  void _removeSelectedCourse(Map<String, dynamic> course) {
    setState(() {
      course['isSelected'] = false;
      selectedCourses.remove(course);
      totalSKS -= course['credits'] as int;
    });
  }

  void _submitKRS() {
    if (selectedCourses.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Pilih minimal 1 mata kuliah'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    if (totalSKS < 12) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('SKS minimal 12, Anda memilih $totalSKS SKS'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Konfirmasi Pengajuan KRS'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Anda akan mengajukan KRS dengan:'),
            SizedBox(height: 8),
            Text('• Total: ${selectedCourses.length} mata kuliah'),
            Text('• Total SKS: $totalSKS'),
            SizedBox(height: 16),
            Text(
              'Pastikan data sudah benar. Setelah diajukan, KRS menunggu persetujuan dosen wali.',
              style: TextStyle(fontSize: 12, color: Colors.grey[700]),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('KRS berhasil diajukan! Menunggu persetujuan dosen wali.'),
                  behavior: SnackBarBehavior.floating,
                  backgroundColor: Colors.green,
                ),
              );
              setState(() {
                selectedCourses.clear();
                totalSKS = 0;
                for (var course in availableCourses) {
                  course['isSelected'] = false;
                }
              });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFF4CAF50),
            ),
            child: Text('Ajukan KRS'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.topRight,
            colors: [
              Color(0xFF2196F3),
              Color(0xFF1976D2),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: Icon(Icons.arrow_back, color: Colors.white),
                          onPressed: () => Navigator.pop(context),
                        ),
                        Expanded(
                          child: Text(
                            'Kartu Rencana Studi',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                          ),
                          child: IconButton(
                            icon: Icon(Icons.info_outline, color: Color(0xFF1976D2)),
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: Text('Informasi KRS'),
                                  content: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('• SKS Minimal: 12 SKS'),
                                      Text('• SKS Maksimal: $maxSKS SKS'),
                                      Text('• Periode KRS: 1-15 Oktober 2025'),
                                      SizedBox(height: 8),
                                      Text(
                                        'Pastikan memilih mata kuliah sesuai kurikulum dan telah memenuhi prasyarat.',
                                        style: TextStyle(fontSize: 12, color: Colors.grey[700]),
                                      ),
                                    ],
                                  ),
                                  actions: [
                                    TextButton(
                                      onPressed: () => Navigator.pop(context),
                                      child: Text('Tutup'),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 16),
                    
                    // SKS Info Card
                    Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            blurRadius: 20,
                            offset: Offset(0, 10),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              children: [
                                Text(
                                  'SKS Terpilih',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey[600],
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  '$totalSKS',
                                  style: TextStyle(
                                    fontSize: 28,
                                    fontWeight: FontWeight.bold,
                                    color: totalSKS > maxSKS ? Colors.red : Color(0xFF2196F3),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: 40,
                            width: 1,
                            color: Colors.grey[300],
                          ),
                          Expanded(
                            child: Column(
                              children: [
                                Text(
                                  'Maks SKS',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey[600],
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  '$maxSKS',
                                  style: TextStyle(
                                    fontSize: 28,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey[800],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: 40,
                            width: 1,
                            color: Colors.grey[300],
                          ),
                          Expanded(
                            child: Column(
                              children: [
                                Text(
                                  'Mata Kuliah',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey[600],
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  '${selectedCourses.length}',
                                  style: TextStyle(
                                    fontSize: 28,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF4CAF50),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Tabs
              Container(
                color: Colors.transparent,
                child: TabBar(
                  controller: _tabController,
                  indicatorColor: Colors.white,
                  indicatorWeight: 3,
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.white.withOpacity(0.6),
                  tabs: [
                    Tab(text: 'Pilih MK'),
                    Tab(text: 'Terpilih (${selectedCourses.length})'),
                    Tab(text: 'Riwayat'),
                  ],
                ),
              ),

              // Content
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.grey[50],
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildAvailableCoursesTab(),
                      _buildSelectedCoursesTab(),
                      _buildHistoryTab(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAvailableCoursesTab() {
    // Jika periode KRS ditutup, tampilkan informasi
    if (!isKRSPeriodActive) {
      return Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Color(0xFFFF9800).withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.lock_clock,
                  size: 80,
                  color: Color(0xFFFF9800),
                ),
              ),
              SizedBox(height: 24),
              Text(
                'Periode KRS Ditutup',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 16),
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: Text(
                  krsPeriodMessage,
                  style: TextStyle(
                    fontSize: 15,
                    color: Colors.grey[700],
                    height: 1.5,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(height: 24),
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Color(0xFFE3F2FD),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Color(0xFF2196F3).withOpacity(0.3)),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Icon(Icons.info_outline, color: Color(0xFF2196F3), size: 20),
                        SizedBox(width: 8),
                        Text(
                          'Informasi Periode KRS',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF1976D2),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Periode pengisian KRS biasanya dibuka 2 minggu sebelum semester baru dimulai. Pantau terus pengumuman untuk informasi pembukaan periode KRS berikutnya.',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.black87,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: () {
                  // Switch ke tab Riwayat
                  _tabController.animateTo(2);
                },
                icon: Icon(Icons.history),
                label: Text('Lihat Riwayat KRS'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF2196F3),
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }
    
    // Kode original untuk periode aktif
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.all(20),
            itemCount: availableCourses.length,
            itemBuilder: (context, index) {
              final course = availableCourses[index];
              final isAvailable = course['enrolled'] < course['capacity'];
              final canSelect = totalSKS + course['credits'] <= maxSKS || course['isSelected'];
              
              return _buildCourseCard(
                course: course,
                isAvailable: isAvailable,
                canSelect: canSelect,
                onTap: () {
                  if (isAvailable && canSelect) {
                    _toggleCourse(index);
                  } else if (!canSelect) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Melebihi batas maksimal SKS ($maxSKS SKS)'),
                        behavior: SnackBarBehavior.floating,
                        backgroundColor: Colors.red,
                      ),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Kelas sudah penuh'),
                        behavior: SnackBarBehavior.floating,
                        backgroundColor: Colors.orange,
                      ),
                    );
                  }
                },
              );
            },
          ),
        ),
        if (selectedCourses.isNotEmpty)
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 10,
                  offset: Offset(0, -5),
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Total: $totalSKS SKS',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: totalSKS > maxSKS ? Colors.red : Colors.black87,
                        ),
                      ),
                      Text(
                        '${selectedCourses.length} mata kuliah dipilih',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                ElevatedButton(
                  onPressed: _submitKRS,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF4CAF50),
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    'Ajukan KRS',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildSelectedCoursesTab() {
    if (selectedCourses.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.inbox_outlined,
              size: 80,
              color: Colors.grey[400],
            ),
            SizedBox(height: 16),
            Text(
              'Belum ada mata kuliah dipilih',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[600],
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Pilih mata kuliah di tab "Pilih MK"',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[500],
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: EdgeInsets.all(20),
      itemCount: selectedCourses.length,
      itemBuilder: (context, index) {
        final course = selectedCourses[index];
        return _buildSelectedCourseCard(course);
      },
    );
  }

  Widget _buildHistoryTab() {
    return ListView.builder(
      padding: EdgeInsets.all(20),
      itemCount: approvedKRS.length,
      itemBuilder: (context, index) {
        final krs = approvedKRS[index];
        return _buildHistoryCard(krs);
      },
    );
  }

  Widget _buildCourseCard({
    required Map<String, dynamic> course,
    required bool isAvailable,
    required bool canSelect,
    required VoidCallback onTap,
  }) {
    final isSelected = course['isSelected'];
    final enrollmentPercentage = (course['enrolled'] / course['capacity']) * 100;
    
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isSelected ? Color(0xFF4CAF50) : Colors.transparent,
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Color(0xFF2196F3).withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  course['code'],
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF1976D2),
                                  ),
                                ),
                              ),
                              SizedBox(width: 8),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Color(0xFF4CAF50).withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.credit_card,
                                      size: 12,
                                      color: Color(0xFF4CAF50),
                                    ),
                                    SizedBox(width: 4),
                                    Text(
                                      '${course['credits']} SKS',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xFF4CAF50),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 8),
                          Text(
                            course['name'],
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color: isSelected ? Color(0xFF4CAF50) : Colors.grey[300],
                        shape: BoxShape.circle,
                      ),
                      child: isSelected
                          ? Icon(Icons.check, color: Colors.white, size: 16)
                          : null,
                    ),
                  ],
                ),
                SizedBox(height: 12),
                Row(
                  children: [
                    Icon(Icons.person, size: 16, color: Colors.grey[600]),
                    SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        course['lecturer'],
                        style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 6),
                Row(
                  children: [
                    Icon(Icons.access_time, size: 16, color: Colors.grey[600]),
                    SizedBox(width: 4),
                    Text(
                      course['schedule'],
                      style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                    ),
                  ],
                ),
                SizedBox(height: 6),
                Row(
                  children: [
                    Icon(Icons.room, size: 16, color: Colors.grey[600]),
                    SizedBox(width: 4),
                    Text(
                      course['room'],
                      style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                    ),
                    Spacer(),
                    Icon(Icons.bookmark, size: 16, color: Colors.grey[600]),
                    SizedBox(width: 4),
                    Text(
                      'Prasyarat: ${course['prerequisite']}',
                      style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                    ),
                  ],
                ),
                SizedBox(height: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Kapasitas',
                          style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                        ),
                        Text(
                          '${course['enrolled']}/${course['capacity']} mahasiswa',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: enrollmentPercentage >= 90 ? Colors.red : Colors.grey[700],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: enrollmentPercentage / 100,
                        backgroundColor: Colors.grey[200],
                        valueColor: AlwaysStoppedAnimation<Color>(
                          enrollmentPercentage >= 90
                              ? Colors.red
                              : enrollmentPercentage >= 75
                                  ? Colors.orange
                                  : Color(0xFF4CAF50),
                        ),
                        minHeight: 6,
                      ),
                    ),
                  ],
                ),
                if (!isAvailable)
                  Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.warning, size: 14, color: Colors.red),
                          SizedBox(width: 4),
                          Text(
                            'Kelas Penuh',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.red,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSelectedCourseCard(Map<String, dynamic> course) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Color(0xFF4CAF50),
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Color(0xFF2196F3).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            course['code'],
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF1976D2),
                            ),
                          ),
                        ),
                        SizedBox(width: 8),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Color(0xFF4CAF50).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            '${course['credits']} SKS',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF4CAF50),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 8),
                    Text(
                      course['name'],
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: Icon(Icons.close, color: Colors.red),
                onPressed: () => _removeSelectedCourse(course),
              ),
            ],
          ),
          SizedBox(height: 12),
          Row(
            children: [
              Icon(Icons.person, size: 16, color: Colors.grey[600]),
              SizedBox(width: 4),
              Expanded(
                child: Text(
                  course['lecturer'],
                  style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                ),
              ),
            ],
          ),
          SizedBox(height: 6),
          Row(
            children: [
              Icon(Icons.access_time, size: 16, color: Colors.grey[600]),
              SizedBox(width: 4),
              Text(
                course['schedule'],
                style: TextStyle(fontSize: 13, color: Colors.grey[700]),
              ),
            ],
          ),
          SizedBox(height: 6),
          Row(
            children: [
              Icon(Icons.room, size: 16, color: Colors.grey[600]),
              SizedBox(width: 4),
              Text(
                course['room'],
                style: TextStyle(fontSize: 13, color: Colors.grey[700]),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryCard(Map<String, dynamic> krs) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  krs['semester'],
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Color(0xFF4CAF50).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.check_circle,
                      size: 16,
                      color: Color(0xFF4CAF50),
                    ),
                    SizedBox(width: 4),
                    Text(
                      krs['status'],
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF4CAF50),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
          Divider(),
          SizedBox(height: 12),
          Row(
            children: [
              Icon(Icons.credit_card, size: 18, color: Colors.grey[600]),
              SizedBox(width: 8),
              Text(
                'Total SKS:',
                style: TextStyle(fontSize: 14, color: Colors.grey[600]),
              ),
              SizedBox(width: 4),
              Text(
                '${krs['totalCredits']} SKS',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
          SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.calendar_today, size: 18, color: Colors.grey[600]),
              SizedBox(width: 8),
              Text(
                'Disetujui:',
                style: TextStyle(fontSize: 14, color: Colors.grey[600]),
              ),
              SizedBox(width: 4),
              Text(
                krs['approvalDate'],
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
          SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.person, size: 18, color: Colors.grey[600]),
              SizedBox(width: 8),
              Text(
                'Dosen Wali:',
                style: TextStyle(fontSize: 14, color: Colors.grey[600]),
              ),
              SizedBox(width: 4),
              Text(
                krs['approvedBy'],
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Download KRS ${krs['semester']}'),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
              icon: Icon(Icons.download, size: 18),
              label: Text('Download KRS'),
              style: OutlinedButton.styleFrom(
                foregroundColor: Color(0xFF2196F3),
                side: BorderSide(color: Color(0xFF2196F3)),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }
}